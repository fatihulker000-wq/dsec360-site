import {
  NextRequest,
  NextResponse,
} from "next/server";

import {
  PDFDocument,
  PDFFont,
  PDFPage,
  rgb,
} from "pdf-lib";

import fontkit from "@pdf-lib/fontkit";
import fs from "fs";
import path from "path";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const A4_PORTRAIT: [number, number] = [595.28, 841.89];
const A4_LANDSCAPE: [number, number] = [841.89, 595.28];

function text(value: unknown): string {
  return String(value ?? "").trim();
}

function formatDate(value?: number | null): string {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return date.toLocaleDateString("tr-TR");
}

function dangerLabel(value?: string | null): string {
  switch (text(value).toUpperCase()) {
    case "AZ_TEHLIKELI":
      return "Az Tehlikeli";
    case "TEHLIKELI":
      return "Tehlikeli";
    case "COK_TEHLIKELI":
      return "Çok Tehlikeli";
    default:
      return text(value) || "-";
  }
}

function renewalYears(value?: string | null): number | null {
  switch (text(value).toUpperCase()) {
    case "AZ_TEHLIKELI":
      return 6;
    case "TEHLIKELI":
      return 4;
    case "COK_TEHLIKELI":
      return 2;
    default:
      return null;
  }
}

function addYears(base: Date, years: number): Date {
  const result = new Date(base);
  result.setFullYear(result.getFullYear() + years);
  return result;
}

function levelLabel(level?: string | null): string {
  switch (level) {
    case "KABUL_EDILEBILIR":
      return "Kabul Edilebilir";
    case "KESIN_RISK":
      return "Kesin Risk";
    case "ONEMLI_RISK":
      return "Önemli Risk";
    case "YUKSEK_RISK":
      return "Yüksek Risk";
    case "COK_YUKSEK_RISK":
      return "Çok Yüksek Risk";
    default:
      return "-";
  }
}

function levelColors(level?: string | null) {
  switch (level) {
    case "KABUL_EDILEBILIR":
      return {
        fill: rgb(0.86, 0.96, 0.86),
        text: rgb(0.06, 0.42, 0.18),
      };
    case "KESIN_RISK":
      return {
        fill: rgb(1.0, 0.95, 0.72),
        text: rgb(0.55, 0.34, 0.02),
      };
    case "ONEMLI_RISK":
      return {
        fill: rgb(1.0, 0.80, 0.35),
        text: rgb(0.35, 0.18, 0.01),
      };
    case "YUKSEK_RISK":
      return {
        fill: rgb(0.96, 0.34, 0.20),
        text: rgb(1, 1, 1),
      };
    case "COK_YUKSEK_RISK":
      return {
        fill: rgb(0.58, 0.03, 0.05),
        text: rgb(1, 1, 1),
      };
    default:
      return {
        fill: rgb(0.95, 0.95, 0.96),
        text: rgb(0.24, 0.26, 0.30),
      };
  }
}

function safeFileName(input: string): string {
  return input
    .toLocaleLowerCase("tr-TR")
    .replaceAll("ı", "i")
    .replaceAll("ğ", "g")
    .replaceAll("ü", "u")
    .replaceAll("ş", "s")
    .replaceAll("ö", "o")
    .replaceAll("ç", "c")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function wrapText(
  input: string,
  maxWidth: number,
  font: PDFFont,
  fontSize: number
): string[] {
  const output: string[] = [];

  for (const paragraph of String(input || "").replace(/\r/g, "").split("\n")) {
    if (!paragraph.trim()) {
      output.push("");
      continue;
    }

    const words = paragraph.split(/\s+/);
    let line = "";

    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(candidate, fontSize) <= maxWidth) {
        line = candidate;
      } else {
        if (line) output.push(line);
        line = word;
      }
    }

    if (line) output.push(line);
  }

  return output;
}

function drawWrapped(
  page: PDFPage,
  value: string,
  x: number,
  y: number,
  width: number,
  font: PDFFont,
  size: number,
  lineHeight = size + 3,
  color = rgb(0.18, 0.2, 0.24)
): number {
  const lines = wrapText(value, width, font, size);
  let currentY = y;

  for (const line of lines) {
    page.drawText(line || " ", {
      x,
      y: currentY,
      size,
      font,
      color,
    });
    currentY -= lineHeight;
  }

  return currentY;
}

function drawSectionTitle(
  page: PDFPage,
  title: string,
  y: number,
  bold: PDFFont
): number {
  page.drawRectangle({
    x: 42,
    y: y - 5,
    width: 511,
    height: 25,
    color: rgb(0.96, 0.94, 0.945),
  });

  page.drawText(title, {
    x: 50,
    y: y + 3,
    size: 11,
    font: bold,
    color: rgb(0.36, 0.09, 0.14),
  });

  return y - 34;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const firmId = text(searchParams.get("firmId"));

    if (!firmId) {
      return NextResponse.json(
        {
          success: false,
          error: "DORA firma ID zorunludur.",
        },
        { status: 400 }
      );
    }

    const { data: firm, error: firmError } = await supabase
      .from("dora_firms")
      .select("*")
      .eq("id", firmId)
      .eq("is_deleted", false)
      .maybeSingle();

    if (firmError) throw firmError;

    if (!firm) {
      return NextResponse.json(
        {
          success: false,
          error: "DORA firması bulunamadı.",
        },
        { status: 404 }
      );
    }

    const { data: risks, error: riskError } = await supabase
      .from("dora_risks")
      .select("*")
      .eq("firm_id", firmId)
      .eq("is_deleted", false)
      .order("fk_score", { ascending: false });

    if (riskError) throw riskError;

    const allRisks = Array.isArray(risks) ? risks : [];

    const { data: riskTeamMembers, error: riskTeamError } = await supabase
      .from("dora_risk_team_members")
      .select("*")
      .eq("firm_id", firmId)
      .eq("is_deleted", false)
      .eq("is_active", true)
      .eq("show_in_report", true)
      .order("sort_order", { ascending: true })
      .order("created_at_millis", { ascending: true });

    if (riskTeamError) throw riskTeamError;

    const reportTeam = Array.isArray(riskTeamMembers)
      ? riskTeamMembers
      : [];

    const roleLabels: Record<string, string> = {
      ISVEREN_VEKILI: "İşveren / İşveren Vekili",
      ISG_UZMANI: "İş Güvenliği Uzmanı",
      ISYERI_HEKIMI: "İşyeri Hekimi",
      CALISAN_TEMSILCISI: "Çalışan Temsilcisi",
      DESTEK_ELEMANI: "Destek Elemanı",
      BIRIM_TEMSILCISI: "Birimleri Temsil Eden Çalışan",
      DIGER: "Diğer Ekip Üyesi",
    };

    function teamRoleLabel(value?: string | null): string {
      return roleLabels[text(value).toUpperCase()] || text(value) || "Diğer Ekip Üyesi";
    }

    function teamMemberLine(member: any): string {
      const parts = [
        text(member.full_name),
        text(member.title) ? `Unvan: ${text(member.title)}` : "",
        text(member.certificate_no) ? `Belge No: ${text(member.certificate_no)}` : "",
      ].filter(Boolean);

      return parts.join(" • ") || "-";
    }

    const regularPath = path.join(
      process.cwd(),
      "public",
      "fonts",
      "NotoSans-Regular.ttf"
    );

    const boldPath = path.join(
      process.cwd(),
      "public",
      "fonts",
      "NotoSans-Bold.ttf"
    );

    if (!fs.existsSync(regularPath)) {
      return NextResponse.json(
        {
          success: false,
          error: "NotoSans-Regular.ttf bulunamadı.",
        },
        { status: 500 }
      );
    }

    const pdf = await PDFDocument.create();
    pdf.registerFontkit(fontkit);

    const regularBytes = fs.readFileSync(regularPath);
    const boldBytes = fs.existsSync(boldPath)
      ? fs.readFileSync(boldPath)
      : regularBytes;

    // Türkçe karakterlerde subset sorunu yaşamamak için tam font gömülür.
    const regular = await pdf.embedFont(regularBytes, { subset: false });
    const bold = await pdf.embedFont(boldBytes, { subset: false });

    const generatedAt = new Date();
    const years = renewalYears(firm.danger_class);
    const periodicRenewal = years ? addYears(generatedAt, years) : null;

    let pageNo = 0;

    function addPortraitPage(title?: string): PDFPage {
      pageNo += 1;
      const page = pdf.addPage(A4_PORTRAIT);
      drawHeaderFooter(page, title || "RİSK DEĞERLENDİRMESİ", false, pageNo);
      return page;
    }

    function addLandscapePage(title?: string): PDFPage {
      pageNo += 1;
      const page = pdf.addPage(A4_LANDSCAPE);
      drawHeaderFooter(page, title || "RİSK DEĞERLENDİRME TABLOSU", true, pageNo);
      return page;
    }

    function drawHeaderFooter(
      page: PDFPage,
      title: string,
      landscape: boolean,
      number: number
    ) {
      const width = landscape ? A4_LANDSCAPE[0] : A4_PORTRAIT[0];
      const height = landscape ? A4_LANDSCAPE[1] : A4_PORTRAIT[1];

      page.drawText(text(firm.firm_name) || "DORA Firma", {
        x: 34,
        y: height - 28,
        size: 9,
        font: bold,
        color: rgb(0.35, 0.09, 0.14),
      });

      const titleWidth = bold.widthOfTextAtSize(title, 8);
      page.drawText(title, {
        x: Math.max(160, (width - titleWidth) / 2),
        y: height - 28,
        size: 8,
        font: bold,
        color: rgb(0.24, 0.26, 0.3),
      });

      page.drawLine({
        start: { x: 34, y: height - 38 },
        end: { x: width - 34, y: height - 38 },
        thickness: 1,
        color: rgb(0.48, 0.15, 0.2),
      });

      page.drawLine({
        start: { x: 34, y: 27 },
        end: { x: width - 34, y: 27 },
        thickness: 0.5,
        color: rgb(0.83, 0.84, 0.86),
      });

      page.drawText("Paraf: __________________", {
        x: 34,
        y: 13,
        size: 6.5,
        font: regular,
        color: rgb(0.42, 0.44, 0.48),
      });

      page.drawText(`Sayfa ${number}`, {
        x: width - 72,
        y: 13,
        size: 6.5,
        font: regular,
        color: rgb(0.42, 0.44, 0.48),
      });
    }

    /* =====================================================
       1. KAPAK
    ===================================================== */

    let page = addPortraitPage("DORA • KURUMSAL RİSK DEĞERLENDİRMESİ");

    page.drawText("İŞ SAĞLIĞI VE GÜVENLİĞİ", {
      x: 70,
      y: 690,
      size: 14,
      font: bold,
      color: rgb(0.48, 0.15, 0.2),
    });

    page.drawText("RİSK DEĞERLENDİRMESİ", {
      x: 70,
      y: 650,
      size: 26,
      font: bold,
      color: rgb(0.1, 0.13, 0.2),
    });

    page.drawText("Fine Kinney Metodu", {
      x: 70,
      y: 620,
      size: 13,
      font: regular,
      color: rgb(0.36, 0.39, 0.45),
    });

    page.drawRectangle({
      x: 70,
      y: 390,
      width: 455,
      height: 170,
      borderWidth: 1,
      borderColor: rgb(0.82, 0.83, 0.85),
      color: rgb(0.99, 0.99, 0.995),
    });

    const coverRows = [
      ["İşyeri Ünvanı", text(firm.firm_name) || "-"],
      ["Adres", text(firm.address) || "-"],
      ["NACE", text(firm.nace_code) || "-"],
      ["Sektör", text(firm.sector) || "-"],
      ["Tehlike Sınıfı", dangerLabel(firm.danger_class)],
      ["Çalışan Sayısı", String(firm.employee_count ?? 0)],
    ];

    let coverY = 535;
    for (const [label, value] of coverRows) {
      page.drawText(label, {
        x: 86,
        y: coverY,
        size: 8.5,
        font: bold,
        color: rgb(0.34, 0.36, 0.4),
      });
      drawWrapped(page, value, 205, coverY, 305, regular, 8.5, 11);
      coverY -= 24;
    }

    page.drawText(`Değerlendirme / Rapor Tarihi: ${generatedAt.toLocaleDateString("tr-TR")}`, {
      x: 70,
      y: 340,
      size: 9,
      font: bold,
      color: rgb(0.24, 0.26, 0.3),
    });

    page.drawText(
      periodicRenewal
        ? `Periyodik azami yenileme tarihi: ${periodicRenewal.toLocaleDateString("tr-TR")}`
        : "Periyodik yenileme tarihi: Tehlike sınıfı bilgisine göre belirlenmelidir.",
      {
        x: 70,
        y: 320,
        size: 8.5,
        font: regular,
        color: rgb(0.34, 0.36, 0.4),
      }
    );

    drawWrapped(
      page,
      "Not: İş kazası, meslek hastalığı, ramak kala, teknoloji/ekipman/üretim yöntemi değişikliği, mevzuat veya çalışma ortamı şartlarındaki değişiklikler gibi Yönetmelikte sayılan hallerde periyodik süre beklenmeden risk değerlendirmesinin tamamen veya kısmen yenilenmesi gerekir.",
      70,
      285,
      455,
      regular,
      8,
      11,
      rgb(0.44, 0.34, 0.18)
    );

    page.drawText("DORA Bağımsız Risk Merkezi", {
      x: 70,
      y: 120,
      size: 10,
      font: bold,
      color: rgb(0.48, 0.15, 0.2),
    });

    drawWrapped(
      page,
      "Bu çıktı yalnızca DORA çalışma alanındaki firma ve Fine Kinney risk kayıtlarından oluşturulmuştur; diğer D-SEC modüllerine veri aktarımı yapmaz.",
      70,
      98,
      455,
      regular,
      8,
      11
    );

    /* =====================================================
       2. AMAÇ, KAPSAM, MEVZUAT, YÖNTEM
    ===================================================== */

    page = addPortraitPage("RİSK DEĞERLENDİRMESİ • YÖNTEM VE DAYANAK");
    let y = 770;

    y = drawSectionTitle(page, "1. AMAÇ VE KAPSAM", y, bold);
    y = drawWrapped(
      page,
      "Bu çalışma; işyerinde mevcut veya dışarıdan gelebilecek tehlikelerin belirlenmesi, bu tehlikelerden kaynaklanan risklerin analiz edilip önceliklendirilmesi, uygun kontrol tedbirlerinin planlanması ve tedbirlerden sonra kalan risk seviyesinin değerlendirilmesi amacıyla hazırlanmıştır.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    ) - 14;

    y = drawSectionTitle(page, "2. MEVZUAT DAYANAĞI", y, bold);
    y = drawWrapped(
      page,
      "6331 sayılı İş Sağlığı ve Güvenliği Kanunu m.10 ve 29.12.2012 tarihli, 28512 sayılı Resmî Gazete'de yayımlanan İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği esas alınmıştır. Dokümantasyon yapısı Yönetmeliğin 11 inci maddesindeki asgari unsurlar dikkate alınarak düzenlenmiştir.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    ) - 14;

    y = drawSectionTitle(page, "3. KULLANILAN YÖNTEM: FINE KINNEY", y, bold);
    y = drawWrapped(
      page,
      "Fine Kinney yönteminde risk skoru Olasılık (O) × Frekans (F) × Şiddet (Ş) çarpımıyla hesaplanır. DORA kayıtlarında ilk risk ve kontrol tedbirlerinden sonraki kalan risk ayrı ayrı değerlendirilir.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    ) - 10;

    const methodRows = [
      ["Olasılık", "0,1 • 0,2 • 0,5 • 1 • 3 • 6 • 10"],
      ["Frekans", "0,5 • 1 • 2 • 3 • 6 • 10"],
      ["Şiddet", "1 • 3 • 7 • 15 • 40 • 100"],
      ["< 20", "Kabul Edilebilir"],
      ["20 – 69", "Kesin Risk"],
      ["70 – 199", "Önemli Risk"],
      ["200 – 399", "Yüksek Risk"],
      ["≥ 400", "Çok Yüksek Risk"],
    ];

    for (const [left, right] of methodRows) {
      page.drawRectangle({
        x: 50,
        y: y - 3,
        width: 495,
        height: 20,
        borderWidth: 0.5,
        borderColor: rgb(0.88, 0.89, 0.91),
      });
      page.drawText(left, {
        x: 58,
        y: y + 3,
        size: 8,
        font: bold,
      });
      page.drawText(right, {
        x: 160,
        y: y + 3,
        size: 8,
        font: regular,
      });
      y -= 20;
    }

    y -= 18;
    y = drawSectionTitle(page, "4. RİSK KONTROL PRENSİBİ", y, bold);
    drawWrapped(
      page,
      "Kontrol tedbirlerinde tehlikenin ortadan kaldırılması, riskle kaynağında mücadele edilmesi ve toplu korunma önlemlerine kişisel korunmaya göre öncelik verilmesi esastır. Kontrol tedbirleri uygulandıktan sonra risk seviyesi yeniden belirlenir; kabul edilebilir seviyenin üzerinde kalan riskler için süreç tekrarlanır.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    );

    /* =====================================================
       3. RİSK DEĞERLENDİRME EKİBİ
    ===================================================== */

    page = addPortraitPage("RİSK DEĞERLENDİRMESİ • EKİP VE ONAY");
    y = 770;
    y = drawSectionTitle(page, "5. RİSK DEĞERLENDİRME EKİBİ", y, bold);

    drawWrapped(
      page,
      "Yönetmelik uyarınca risk değerlendirmesi ekip tarafından gerçekleştirilir. Aşağıdaki alanlar nihai doküman kullanılmadan önce gerçek isim, unvan ve gerekli belge bilgileriyle tamamlanmalıdır.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    );
    y -= 52;

    const team =
      reportTeam.length > 0
        ? reportTeam.map((member: any) => [
            teamRoleLabel(member.role_type),
            teamMemberLine(member),
          ])
        : [
            [
              "İşveren / İşveren Vekili",
              text(firm.authorized_person) ||
                "................................................",
            ],
            [
              "Risk Değerlendirme Ekibi",
              "DORA Risk Değerlendirme Ekibi kaydı bulunamadı.",
            ],
          ];

    for (const [role, member] of team) {
      if (y < 120) {
        page = addPortraitPage("RİSK DEĞERLENDİRMESİ • EKİP VE ONAY");
        y = 770;
        y = drawSectionTitle(page, "5. RİSK DEĞERLENDİRME EKİBİ (DEVAM)", y, bold);
      }

      page.drawRectangle({
        x: 50,
        y: y - 8,
        width: 495,
        height: 52,
        borderWidth: 0.6,
        borderColor: rgb(0.83, 0.84, 0.86),
      });
      page.drawText(role, {
        x: 58,
        y: y + 23,
        size: 8,
        font: bold,
      });
      drawWrapped(page, member, 190, y + 23, 345, regular, 7.2, 9);
      page.drawText("İmza / Paraf: ____________________", {
        x: 190,
        y: y + 2,
        size: 7,
        font: regular,
        color: rgb(0.42, 0.44, 0.48),
      });
      y -= 52;
    }

    y -= 15;
    y = drawSectionTitle(page, "6. İŞYERİ VE DEĞERLENDİRME BİLGİLERİ", y, bold);
    const info = [
      `İşyeri: ${text(firm.firm_name) || "-"}`,
      `Adres: ${text(firm.address) || "-"}`,
      `Tehlike Sınıfı: ${dangerLabel(firm.danger_class)}`,
      `Değerlendirme Tarihi: ${generatedAt.toLocaleDateString("tr-TR")}`,
      periodicRenewal
        ? `Periyodik azami yenileme tarihi: ${periodicRenewal.toLocaleDateString("tr-TR")}`
        : "Periyodik yenileme tarihi: Tehlike sınıfı bilgisi tamamlanmalıdır.",
      `Değerlendirilen risk kaydı sayısı: ${allRisks.length}`,
    ];

    for (const item of info) {
      y = drawWrapped(page, item, 50, y, 495, regular, 8, 11) - 3;
    }

    /* =====================================================
       4. RİSK TABLOSU
       KURUMSAL - AYRI BÖLÜM / FAALİYET / TEHLİKE / RİSK
       İLK VE KALAN RİSK ALT BAŞLIKLARI AYRI
    ===================================================== */

    type RiskTableColumn = {
      key: string;
      label: string;
      width: number;
      group?: "INITIAL" | "RESIDUAL";
      levelCell?: boolean;
    };

    const columns: RiskTableColumn[] = [
      { key: "no", label: "No", width: 18 },
      { key: "department", label: "Bölüm", width: 40 },
      { key: "activity", label: "Faaliyet", width: 40 },
      { key: "hazard", label: "Tehlike", width: 55 },
      { key: "risk", label: "Risk", width: 60 },
      { key: "existing", label: "Mevcut Önlemler", width: 62 },

      { key: "probability", label: "O", width: 23, group: "INITIAL" },
      { key: "frequency", label: "F", width: 23, group: "INITIAL" },
      { key: "severity", label: "Ş", width: 24, group: "INITIAL" },
      { key: "score", label: "Skor", width: 30, group: "INITIAL" },

      { key: "level", label: "Risk Seviyesi", width: 50, levelCell: true },

      { key: "action", label: "Alınacak Tedbirler", width: 68 },
      { key: "owner", label: "Sorumlu", width: 45 },
      { key: "due", label: "Termin", width: 45 },

      { key: "rProbability", label: "O", width: 23, group: "RESIDUAL" },
      { key: "rFrequency", label: "F", width: 23, group: "RESIDUAL" },
      { key: "rSeverity", label: "Ş", width: 24, group: "RESIDUAL" },
      { key: "rScore", label: "Skor", width: 30, group: "RESIDUAL" },

      {
        key: "rLevel",
        label: "Kalan Risk Seviyesi",
        width: 50,
        levelCell: true,
      },

      { key: "basis", label: "Mevzuat", width: 65 },
    ];

    const tableX = 20;
    const tableTop = 535;
    const tableBottom = 42;

    const firstHeaderHeight = 23;
    const secondHeaderHeight = 23;
    const headerHeight = firstHeaderHeight + secondHeaderHeight;

    const initialColumns = columns.filter(
      (column) => column.group === "INITIAL"
    );

    const residualColumns = columns.filter(
      (column) => column.group === "RESIDUAL"
    );

    const initialWidth = initialColumns.reduce(
      (sum, column) => sum + column.width,
      0
    );

    const residualWidth = residualColumns.reduce(
      (sum, column) => sum + column.width,
      0
    );

    function drawHeaderCell(
      target: PDFPage,
      x: number,
      yTop: number,
      width: number,
      height: number,
      label: string,
      size = 5.4
    ) {
      target.drawRectangle({
        x,
        y: yTop - height,
        width,
        height,
        borderWidth: 0.6,
        borderColor: rgb(0.70, 0.71, 0.74),
        color: rgb(0.40, 0.03, 0.06),
      });

      const lines = wrapText(
        label,
        Math.max(8, width - 6),
        bold,
        size
      );

      const totalTextHeight =
        Math.max(1, lines.length) * (size + 1.5);

      let lineY =
        yTop -
        (height - totalTextHeight) / 2 -
        size;

      for (const line of lines) {
        const textWidth =
          bold.widthOfTextAtSize(
            line,
            size
          );

        target.drawText(
          line || " ",
          {
            x:
              x +
              Math.max(
                3,
                (width - textWidth) / 2
              ),
            y: lineY,
            size,
            font: bold,
            color: rgb(1, 1, 1),
          }
        );

        lineY -= size + 1.5;
      }
    }

    function drawTableHeader(
      target: PDFPage,
      yTop: number
    ) {
      let x = tableX;

      for (
        let index = 0;
        index < columns.length;
        index += 1
      ) {
        const column =
          columns[index];

        if (
          column.group ===
          "INITIAL"
        ) {
          if (
            column.key ===
            "probability"
          ) {
            drawHeaderCell(
              target,
              x,
              yTop,
              initialWidth,
              firstHeaderHeight,
              "İlk Risk (Olasılık - Frekans - Şiddet - Skor)",
              5.6
            );
          }

          drawHeaderCell(
            target,
            x,
            yTop -
              firstHeaderHeight,
            column.width,
            secondHeaderHeight,
            column.label,
            5.4
          );

          x +=
            column.width;

          continue;
        }

        if (
          column.group ===
          "RESIDUAL"
        ) {
          if (
            column.key ===
            "rProbability"
          ) {
            drawHeaderCell(
              target,
              x,
              yTop,
              residualWidth,
              firstHeaderHeight,
              "Kalan Risk (Olasılık - Frekans - Şiddet - Skor)",
              5.6
            );
          }

          drawHeaderCell(
            target,
            x,
            yTop -
              firstHeaderHeight,
            column.width,
            secondHeaderHeight,
            column.label,
            5.4
          );

          x +=
            column.width;

          continue;
        }

        drawHeaderCell(
          target,
          x,
          yTop,
          column.width,
          headerHeight,
          column.label,
          5.1
        );

        x +=
          column.width;
      }
    }

    function cellLines(
      value: string,
      width: number,
      font = regular,
      size = 5.45
    ) {
      return wrapText(
        value || "-",
        Math.max(8, width - 6),
        font,
        size
      );
    }

    page = addLandscapePage(
      "KURUMSAL FINE KINNEY RİSK DEĞERLENDİRME TABLOSU"
    );

    drawTableHeader(
      page,
      tableTop
    );

    let tableY =
      tableTop -
      headerHeight;

    if (
      allRisks.length === 0
    ) {
      page.drawText(
        "Kayıtlı risk bulunmamaktadır.",
        {
          x: tableX,
          y: tableY - 24,
          size: 9,
          font: regular,
        }
      );
    }

    for (
      let index = 0;
      index < allRisks.length;
      index += 1
    ) {
      const risk =
        allRisks[index];

      const riskText =
        [
          text(
            risk.risk_description
          ),
          text(
            risk.consequence
          ),
        ]
          .filter(Boolean)
          .join(" - ") ||
        "-";

      const hasResidual =
        risk.residual_score !=
        null;

      const values: Record<
        string,
        string
      > = {
        no:
          String(index + 1),

        department:
          text(
            risk.department
          ) || "-",

        activity:
          text(
            risk.activity
          ) || "-",

        hazard:
          text(
            risk.hazard
          ) || "-",

        risk:
          riskText,

        existing:
          text(
            risk.existing_controls
          ) || "-",

        probability:
          String(
            risk.fk_probability ??
            "-"
          ),

        frequency:
          String(
            risk.fk_frequency ??
            "-"
          ),

        severity:
          String(
            risk.fk_severity ??
            "-"
          ),

        score:
          String(
            risk.fk_score ??
            "-"
          ),

        level:
          levelLabel(
            risk.fk_level
          ),

        action:
          text(
            risk.corrective_action
          ) || "-",

        owner:
          text(
            risk.responsible_person
          ) || "-",

        due:
          formatDate(
            risk.due_date_millis
          ),

        rProbability:
          hasResidual
            ? String(
                risk.residual_probability ??
                "-"
              )
            : "-",

        rFrequency:
          hasResidual
            ? String(
                risk.residual_frequency ??
                "-"
              )
            : "-",

        rSeverity:
          hasResidual
            ? String(
                risk.residual_severity ??
                "-"
              )
            : "-",

        rScore:
          hasResidual
            ? String(
                risk.residual_score
              )
            : "-",

        rLevel:
          hasResidual
            ? levelLabel(
                risk.residual_level
              )
            : "Değerlendirilmedi",

        basis:
          text(
            risk.legal_basis
          ) || "-",
      };

      const prepared =
        columns.map(
          (column) =>
            cellLines(
              values[
                column.key
              ],
              column.width,
              column.levelCell
                ? bold
                : regular,
              column.levelCell
                ? 5.0
                : 5.45
            )
        );

      const maxLines =
        Math.max(
          ...prepared.map(
            (lines) =>
              Math.max(
                1,
                lines.length
              )
          )
        );

      const rowHeight =
        Math.max(
          32,
          maxLines * 7 +
            10
        );

      if (
        tableY -
          rowHeight <
        tableBottom
      ) {
        page =
          addLandscapePage(
            "KURUMSAL FINE KINNEY RİSK DEĞERLENDİRME TABLOSU"
          );

        drawTableHeader(
          page,
          tableTop
        );

        tableY =
          tableTop -
          headerHeight;
      }

      let x =
        tableX;

      columns.forEach(
        (
          column,
          columnIndex
        ) => {
          let fill =
            index % 2 === 0
              ? rgb(
                  1,
                  1,
                  1
                )
              : rgb(
                  0.985,
                  0.987,
                  0.99
                );

          let textColor =
            rgb(
              0.18,
              0.20,
              0.24
            );

          if (
            column.key ===
            "level"
          ) {
            const color =
              levelColors(
                risk.fk_level
              );

            fill =
              color.fill;

            textColor =
              color.text;
          }

          if (
            column.key ===
            "rLevel"
          ) {
            const color =
              hasResidual
                ? levelColors(
                    risk.residual_level
                  )
                : {
                    fill: rgb(
                      0.95,
                      0.95,
                      0.96
                    ),
                    text: rgb(
                      0.38,
                      0.40,
                      0.44
                    ),
                  };

            fill =
              color.fill;

            textColor =
              color.text;
          }

          page.drawRectangle({
            x,
            y:
              tableY -
              rowHeight,
            width:
              column.width,
            height:
              rowHeight,
            borderWidth: 0.5,
            borderColor:
              rgb(
                0.82,
                0.83,
                0.85
              ),
            color:
              fill,
          });

          const lines =
            prepared[
              columnIndex
            ];

          const fontSize =
            column.levelCell
              ? 5.0
              : 5.45;

          const lineHeight =
            7;

          const blockHeight =
            Math.max(
              1,
              lines.length
            ) *
            lineHeight;

          let lineY =
            tableY -
            Math.max(
              10,
              (
                rowHeight -
                blockHeight
              ) /
                2 +
                fontSize
            );

          for (
            const line of
            lines
          ) {
            page.drawText(
              line || " ",
              {
                x:
                  x +
                  3,
                y:
                  lineY,
                size:
                  fontSize,
                font:
                  column.levelCell
                    ? bold
                    : regular,
                color:
                  textColor,
              }
            );

            lineY -=
              lineHeight;
          }

          x +=
            column.width;
        }
      );

      tableY -=
        rowHeight;
    }

    /* =====================================================
       5. SONUÇ / İMZA
    ===================================================== */

    page = addPortraitPage("RİSK DEĞERLENDİRMESİ • SONUÇ VE İMZA");
    y = 770;

    y = drawSectionTitle(page, "7. GENEL SONUÇ VE İZLEME", y, bold);

    const counts = {
      acceptable: allRisks.filter((r) => r.fk_level === "KABUL_EDILEBILIR").length,
      definite: allRisks.filter((r) => r.fk_level === "KESIN_RISK").length,
      important: allRisks.filter((r) => r.fk_level === "ONEMLI_RISK").length,
      high: allRisks.filter((r) => r.fk_level === "YUKSEK_RISK").length,
      veryHigh: allRisks.filter((r) => r.fk_level === "COK_YUKSEK_RISK").length,
    };

    y = drawWrapped(
      page,
      `Toplam ${allRisks.length} risk kaydı değerlendirilmiştir. Dağılım: Kabul Edilebilir ${counts.acceptable}, Kesin Risk ${counts.definite}, Önemli Risk ${counts.important}, Yüksek Risk ${counts.high}, Çok Yüksek Risk ${counts.veryHigh}. Kontrol tedbirlerinin uygulanması, terminlerin izlenmesi ve kontrol sonrasında kalan riskin yeniden değerlendirilmesi gereklidir.`,
      50,
      y,
      495,
      regular,
      8.5,
      12
    ) - 16;

    y = drawSectionTitle(page, "8. DOKÜMANTASYON VE SAKLAMA", y, bold);
    y = drawWrapped(
      page,
      "Risk değerlendirmesi dokümanı elektronik ortamda hazırlanıp arşivlenebilir. Nihai kullanımda dokümanın sayfaları numaralandırılmalı, değerlendirmeyi gerçekleştiren kişilerce her sayfa paraflanmalı ve son sayfa imzalanmalıdır. Ekip isim/unvan ve uzman/hekim belge bilgilerinin eksiksiz olması gerekir.",
      50,
      y,
      495,
      regular,
      8.5,
      12
    ) - 20;

    y = drawSectionTitle(page, "9. SON SAYFA İMZALARI", y, bold);

    const signRows =
      reportTeam.length > 0
        ? reportTeam.map((member: any) => [
            teamRoleLabel(member.role_type),
            teamMemberLine(member),
          ])
        : [
            [
              "İşveren / İşveren Vekili",
              text(firm.authorized_person) || "................................",
            ],
            [
              "Risk Değerlendirme Ekibi",
              "DORA ekip kaydı bulunamadı.",
            ],
          ];

    for (const [role, name] of signRows) {
      if (y < 105) {
        page = addPortraitPage("RİSK DEĞERLENDİRMESİ • SON SAYFA İMZALARI");
        y = 770;
        y = drawSectionTitle(page, "9. SON SAYFA İMZALARI (DEVAM)", y, bold);
      }

      page.drawRectangle({
        x: 50,
        y: y - 5,
        width: 495,
        height: 56,
        borderWidth: 0.6,
        borderColor: rgb(0.83, 0.84, 0.86),
      });
      page.drawText(role, {
        x: 58,
        y: y + 28,
        size: 8,
        font: bold,
      });
      drawWrapped(page, name, 205, y + 28, 220, regular, 7.2, 9);
      page.drawText("İmza: __________________", {
        x: 430,
        y: y + 20,
        size: 7,
        font: regular,
      });
      y -= 56;
    }

    const bytes = await pdf.save();
    const fileName = safeFileName(text(firm.firm_name) || "dora-firma");

    return new NextResponse(new Uint8Array(bytes), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${fileName || "dora"}-kurumsal-risk-degerlendirmesi.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    console.error("DORA ASSESSMENT REPORT ERROR:", error);

    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Kurumsal DORA risk değerlendirme raporu oluşturulamadı.",
      },
      { status: 500 }
    );
  }
}