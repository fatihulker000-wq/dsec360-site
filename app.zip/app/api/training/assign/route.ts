import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { appendTrainingAuditEvent } from "../../../../lib/training-audit";

function sha256(input: string) {
  return crypto.createHash("sha256").update(input).digest("hex");
}

function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

type UserRow = {
  id: string;
  employee_id: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  company_id: string | null;
};

type EmployeeRow = {
  id: string;
  firm_id: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  active: boolean | null;
};

type TrainingRow = {
  id: string;
  title: string | null;
  description: string | null;
  type: string | null;
};

type AssignmentRow = {
  id?: string;
  user_id: string;
  training_id: string;
};

function generatePassword() {
  return Math.random().toString(36).slice(-8);
}

function escapeHtml(value: string) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function isValidEmail(email?: string | null) {
  if (!email) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function getTrainingTypeLabel(type?: string | null) {
  const value = String(type || "").trim().toLowerCase();
  if (value === "senkron") return "Senkron Eğitim";
  if (value === "asenkron") return "Asenkron Eğitim";
  return type || "Eğitim";
}

function getSafeTrainingDescription(description?: string | null) {
  const raw = String(description || "").trim();
  if (!raw) return "Bu eğitim için sistemde ek açıklama bulunmamaktadır.";
  return raw.length > 500 ? `${raw.slice(0, 497)}...` : raw;
}

async function insertMailLog(params: {
  supabase: ReturnType<typeof getSupabase>;
  userId: string;
  email: string | null;
  trainingTitle: string | null;
  status: "sent" | "failed";
  errorText?: string | null;
}) {
  try {
    const { error } = await params.supabase.from("mail_logs").insert({
      user_id: params.userId,
      email: params.email,
      training_title: params.trainingTitle,
      status: params.status,
      error: params.errorText || null,
      created_at: new Date().toISOString(),
    });

    if (error) {
      console.error("MAIL LOG INSERT ERROR:", error);
    }
  } catch (err) {
    console.error("MAIL LOG INSERT GENERAL ERROR:", err);
  }
}

async function sendTrainingInviteEmail(params: {
  to: string;
  fullName: string;
  trainingTitle: string;
  trainingDescription?: string | null;
  trainingType?: string | null;
  tempPassword: string;
}) {
  const apiKey = process.env.RESEND_API_KEY;
  const emailFrom = process.env.EMAIL_FROM;
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://dsec360.com";

  if (!apiKey || !emailFrom) {
    return {
      ok: false,
      reason:
        "Mail ortam değişkenleri eksik. RESEND_API_KEY veya EMAIL_FROM tanımlı değil.",
    };
  }

  const loginUrl = `${appUrl.replace(/\/$/, "")}/portal/training`;
  const safeName = escapeHtml(params.fullName);
  const safeTraining = escapeHtml(params.trainingTitle);
  const safePassword = escapeHtml(params.tempPassword);
  const safeLoginUrl = escapeHtml(loginUrl);
  const safeTrainingType = escapeHtml(getTrainingTypeLabel(params.trainingType));
  const safeTrainingDescription = escapeHtml(
    getSafeTrainingDescription(params.trainingDescription)
  );

  const html = `
    <div style="font-family:Arial,Helvetica,sans-serif;background:#f3f4f6;padding:30px;color:#111827;">
      <div style="max-width:700px;margin:0 auto;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid #e5e7eb;box-shadow:0 10px 30px rgba(0,0,0,0.08);">
        <div style="background:linear-gradient(135deg,#0f172a,#1e293b);padding:26px;text-align:center;">
          <div style="font-size:24px;font-weight:900;color:#ffffff;letter-spacing:0.3px;">D-SEC</div>
          <div style="font-size:13px;color:#cbd5e1;margin-top:6px;">Dijital Sağlık • Emniyet • Çevre</div>
        </div>

        <div style="padding:30px 28px;">
          <div style="display:inline-block;padding:8px 12px;border-radius:999px;background:#eff6ff;border:1px solid #bfdbfe;color:#1d4ed8;font-size:12px;font-weight:700;margin-bottom:18px;">
            Yeni Eğitim Ataması
          </div>

          <p style="font-size:15px;margin:0 0 16px;line-height:1.7;">
            Merhaba <strong>${safeName}</strong>,
          </p>

          <p style="font-size:15px;line-height:1.8;margin:0 0 16px;color:#374151;">
            D-SEC Eğitim Portalı üzerinden tarafınıza aşağıdaki eğitim tanımlanmıştır:
          </p>

          <div style="background:#f9fafb;border-radius:14px;padding:18px;margin:18px 0;border:1px solid #e5e7eb;">
            <div style="font-size:13px;color:#6b7280;">Eğitim Adı</div>
            <div style="font-size:20px;font-weight:800;color:#111827;margin-top:6px;">
              ${safeTraining}
            </div>

            <div style="margin-top:16px;font-size:13px;color:#6b7280;">Eğitim Tipi</div>
            <div style="font-size:15px;font-weight:700;color:#374151;margin-top:6px;">
              ${safeTrainingType}
            </div>

            <div style="margin-top:16px;font-size:13px;color:#6b7280;">Eğitim Açıklaması</div>
            <div style="font-size:14px;line-height:1.8;color:#374151;margin-top:6px;">
              ${safeTrainingDescription}
            </div>
          </div>

          <p style="font-size:14px;line-height:1.8;margin:0 0 16px;color:#374151;">
            Eğitime erişim sağlamak için aşağıda yer alan portal bağlantısı ve geçici giriş bilgilerini kullanabilirsiniz.
          </p>

          <div style="background:#f9fafb;border-radius:14px;padding:18px;margin:20px 0;border:1px solid #e5e7eb;">
            <div style="font-size:13px;color:#6b7280;">Portal Giriş Linki</div>
            <div style="font-weight:700;margin:6px 0 14px;word-break:break-all;color:#111827;">
              ${safeLoginUrl}
            </div>

           <div style="font-size:13px;color:#6b7280;">Giriş Şifreniz</div>
            <div style="font-size:24px;font-weight:900;color:#16a34a;margin-top:6px;letter-spacing:0.4px;">
              ${safePassword}
            </div>
          </div>

          <div style="margin-top:20px;">
            <a
              href="${safeLoginUrl}"
              style="display:inline-block;background:#111827;color:#ffffff;padding:13px 22px;border-radius:10px;text-decoration:none;font-weight:800;font-size:14px;"
            >
              Eğitime Başla
            </a>
          </div>
        </div>

        <div style="background:#f9fafb;padding:18px;text-align:center;font-size:12px;color:#6b7280;border-top:1px solid #e5e7eb;">
          © ${new Date().getFullYear()} D-SEC
          <br />
          www.dsec360.com
        </div>
      </div>
    </div>
  `;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: emailFrom,
        to: [params.to],
        subject: `D-SEC Eğitim Ataması: ${params.trainingTitle}`,
        html,
      }),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return {
        ok: false,
        reason:
          data?.message ||
          data?.error ||
          data?.name ||
          `Mail gönderilemedi. HTTP ${response.status}`,
      };
    }

    return { ok: true };
  } catch (err: any) {
    return {
      ok: false,
      reason: err?.message || "Mail servisine bağlanılamadı.",
    };
  }
}

export async function POST(req: Request) {
  try {
    const cookieStore = await cookies();
    const adminAuth = cookieStore.get("dsec_admin_auth")?.value;
    const adminRole = cookieStore.get("dsec_admin_role")?.value;
    const companyIdFromCookie = String(
      cookieStore.get("dsec_company_id")?.value || ""
    ).trim();

    const isAllowedRole =
      adminRole === "super_admin" || adminRole === "company_admin";

    if (adminAuth !== "ok" || !isAllowedRole) {
      return NextResponse.json({ error: "Yetkisiz erişim." }, { status: 401 });
    }

    if (adminRole === "company_admin" && !companyIdFromCookie) {
      return NextResponse.json(
        { error: "Firma yöneticisi için firma bilgisi bulunamadı." },
        { status: 403 }
      );
    }

    const body = await req.json();

    const employeeIds = Array.isArray(body?.employeeIds)
  ? body.employeeIds.map((x: unknown) => String(x)).filter(Boolean)
  : [];

const trainingId = body?.trainingId ? String(body.trainingId) : "";
const companyId = body?.companyId ? String(body.companyId).trim() : "";

if (!employeeIds.length || !trainingId || !companyId || companyId === "all") {
  return NextResponse.json(
    { error: "Eğitim, firma ve çalışan seçimi zorunludur." },
    { status: 400 }
  );
}

const uniqueEmployeeIds = Array.from(new Set(employeeIds));
const supabase = getSupabase();

    const { data: training, error: trainingError } = await supabase
      .from("trainings")
      .select("id, title, description, type")
      .eq("id", trainingId)
      .maybeSingle<TrainingRow>();

    if (trainingError || !training) {
      return NextResponse.json(
        { error: "Eğitim bilgisi alınamadı." },
        { status: 500 }
      );
    }

    const { data: employeesData, error: employeesError } = await supabase
  .from("employees")
  .select("id, firm_id, full_name, email, phone, active")
  .in("id", uniqueEmployeeIds);

if (employeesError) {
  return NextResponse.json(
    { error: "Çalışanlar alınamadı." },
    { status: 500 }
  );
}

const typedEmployees = (employeesData || []) as EmployeeRow[];

if (typedEmployees.length !== uniqueEmployeeIds.length) {
  return NextResponse.json(
    { error: "Seçilen çalışanların bir kısmı bulunamadı." },
    { status: 400 }
  );
}

const wrongFirmEmployee = typedEmployees.find(
  (emp) => String(emp.firm_id || "").trim() !== companyId
);

if (wrongFirmEmployee) {
  return NextResponse.json(
    { error: "Seçilen çalışanlar seçili firmaya ait değil." },
    { status: 400 }
  );
}

const passiveEmployee = typedEmployees.find((emp) => emp.active === false);

if (passiveEmployee) {
  return NextResponse.json(
    { error: "Pasif çalışana eğitim atanamaz." },
    { status: 400 }
  );
}

const { data: users, error: usersError } = await supabase
  .from("users")
  .select("id, employee_id, full_name, email, phone, company_id")
  .in("employee_id", uniqueEmployeeIds);

if (usersError) {
  return NextResponse.json(
    { error: "Eğitim kullanıcıları alınamadı." },
    { status: 500 }
  );
}

const typedUsers = (users || []) as UserRow[];

const missingUserEmployees = typedEmployees.filter(
  (emp) => !typedUsers.some((user) => user.employee_id === emp.id)
);

if (missingUserEmployees.length > 0) {
  return NextResponse.json(
    {
      error:
        "Seçilen çalışanlardan bazıları eğitim kullanıcısına bağlı değil. Önce çalışan için eğitim kullanıcı bağlantısı oluşturulmalı.",
    },
    { status: 400 }
  );
}

const uniqueUserIds = Array.from(new Set(typedUsers.map((u) => u.id)));

const usersWithoutEmployee = typedUsers.filter(
  (user) => !String(user.employee_id || "").trim()
);

if (usersWithoutEmployee.length > 0) {
  return NextResponse.json(
    { error: "Çalışanlar modülüne bağlı olmayan kullanıcıya eğitim atanamaz." },
    { status: 400 }
  );
}

    if (typedUsers.length !== uniqueUserIds.length) {
      return NextResponse.json(
        { error: "Seçilen kullanıcıların bir kısmı bulunamadı." },
        { status: 400 }
      );
    }

   if (adminRole === "company_admin") {
  const unauthorizedUser = typedUsers.find(
    (user) => String(user.company_id || "").trim() !== companyIdFromCookie
  );

  const unauthorizedEmployee = typedEmployees.find(
    (emp) => String(emp.firm_id || "").trim() !== companyIdFromCookie
  );

      if (unauthorizedUser || unauthorizedEmployee) {
        return NextResponse.json(
          { error: "Sadece kendi firmanızdaki çalışanlara eğitim atayabilirsiniz." },
          { status: 403 }
        );
      }
    }

    const { data: existingRows, error: existingError } = await supabase
      .from("training_assignments")
      .select("id, user_id, training_id")
      .eq("training_id", trainingId)
      .in("user_id", uniqueUserIds);

    if (existingError) {
      return NextResponse.json(
        { error: "Mevcut atamalar kontrol edilemedi." },
        { status: 500 }
      );
    }

    const existingSet = new Set(
      ((existingRows || []) as AssignmentRow[]).map(
        (row) => `${row.user_id}::${row.training_id}`
      )
    );

    const assignableUsers: Array<{
      user: UserRow;
      tempPassword: string;
    }> = [];

    let skippedCount = 0;

    for (const user of typedUsers) {
      const exists = existingSet.has(`${user.id}::${trainingId}`);

      if (exists) {
        skippedCount += 1;
        continue;
      }

      assignableUsers.push({
        user,
        tempPassword: generatePassword(),
      });
    }

    if (assignableUsers.length === 0) {
      return NextResponse.json({
        success: true,
        insertedCount: 0,
        skippedCount,
        emailedCount: 0,
        mailFailedCount: 0,
        noEmailCount: 0,
        trainingTitle: training.title,
        message:
          "Yeni atama yapılmadı. Seçilen kullanıcıların tamamında bu eğitim zaten vardı.",
        mailResults: [],
      });
    }

    const inserts = assignableUsers.map(({ user }) => ({
      user_id: user.id,
      training_id: trainingId,
      status: "not_started" as const,
    }));

    const { data: insertedAssignments, error: insertError } = await supabase
      .from("training_assignments")
      .insert(inserts)
      .select("id, user_id, training_id");

    if (insertError) {
      console.error("ASSIGNMENT INSERT ERROR:", insertError);
      return NextResponse.json(
        { error: "Atama kaydı başarısız." },
        { status: 500 }
      );
    }

    const insertedAssignmentRows =
      (insertedAssignments || []) as AssignmentRow[];

    const assignableUserMap = new Map(
      assignableUsers.map((item) => [item.user.id, item.user])
    );

    // Audit kaydı ana atama işlemini asla bozmamalı.
    // Sadece gerçekten yeni eklenen atamalar için ASSIGNED olayı yazılır.
    for (const assignment of insertedAssignmentRows) {
      const user = assignableUserMap.get(assignment.user_id);
      if (!user) continue;

      try {
        await appendTrainingAuditEvent({
          assignmentId: assignment.id || null,
          trainingId,
          userId: user.id,
          employeeId: user.employee_id || null,
          companyId,
          eventType: "ASSIGNED",
          eventLabel: "Eğitim atandı",
          eventStatus: "info",
          source: "api/training/assign",
          metadata: {
            training_title: training.title || "D-SEC Eğitimi",
            training_type: training.type || null,
            employee_name: user.full_name || null,
            email: user.email || null,
            company_id: companyId,
          },
          currentData: {
            status: "not_started",
            training_id: trainingId,
            user_id: user.id,
          },
        });
      } catch (auditError) {
        console.error(
          "TRAINING ASSIGNED AUDIT ERROR:",
          auditError
        );
      }
    }

    let emailedCount = 0;
    let mailFailedCount = 0;
    let noEmailCount = 0;

    const mailResults: Array<{
      userId: string;
      email: string | null;
      ok: boolean;
      reason?: string;
    }> = [];

    for (const item of assignableUsers) {
      const user = item.user;
      const tempPassword = item.tempPassword;

     const { error: updateUserError } = await supabase
  .from("users")
  .update({
    password_hash: sha256(tempPassword),
    role: "training_user",
  })
  .eq("id", user.id);

      if (updateUserError) {
        console.error("TEMP PASSWORD UPDATE ERROR:", updateUserError);
      }

      if (!isValidEmail(user.email)) {
        noEmailCount += 1;

        mailResults.push({
          userId: user.id,
          email: user.email,
          ok: false,
          reason: "Kullanıcı email bilgisi yok veya email formatı geçersiz.",
        });

        await insertMailLog({
          supabase,
          userId: user.id,
          email: user.email,
          trainingTitle: training.title,
          status: "failed",
          errorText: "Kullanıcı email bilgisi yok veya email formatı geçersiz.",
        });

        continue;
      }

      const mailResult = await sendTrainingInviteEmail({
        to: user.email!.trim(),
        fullName: user.full_name || "Kullanıcı",
        trainingTitle: training.title || "D-SEC Eğitimi",
        trainingDescription: training.description,
        trainingType: training.type,
        tempPassword,
      });

      if (mailResult.ok) {
        emailedCount += 1;
      } else {
        mailFailedCount += 1;
      }

      mailResults.push({
        userId: user.id,
        email: user.email,
        ok: mailResult.ok,
        reason: mailResult.ok ? undefined : mailResult.reason,
      });

      await insertMailLog({
        supabase,
        userId: user.id,
        email: user.email,
        trainingTitle: training.title,
        status: mailResult.ok ? "sent" : "failed",
        errorText: mailResult.ok ? null : mailResult.reason,
      });
    }

    return NextResponse.json({
      success: true,
      insertedCount: assignableUsers.length,
      skippedCount,
      emailedCount,
      mailFailedCount,
      noEmailCount,
      trainingTitle: training.title,
      message: "Eğitim atandı. Mail gönderimleri işlendi.",
      mailResults,
    });
  } catch (err) {
    console.error("TRAINING ASSIGN GENERAL ERROR:", err);
    return NextResponse.json({ error: "Sunucu hatası" }, { status: 500 });
  }
}