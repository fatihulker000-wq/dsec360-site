import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const MOBILE_API_KEY = "dsec_mobile_123";

function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

function authorized(req: Request) {
  const headerKey = String(req.headers.get("x-api-key") || "").trim();

  const authHeader = String(req.headers.get("authorization") || "").trim();
  const bearerKey = authHeader.toLowerCase().startsWith("bearer ")
    ? authHeader.slice(7).trim()
    : "";

  const url = new URL(req.url);
  const queryKey = String(url.searchParams.get("apiKey") || "").trim();

  return (
    headerKey === MOBILE_API_KEY ||
    bearerKey === MOBILE_API_KEY ||
    queryKey === MOBILE_API_KEY
  );
}

function unauthorized() {
  return NextResponse.json({ error: "Yetkisiz." }, { status: 401 });
}

function clean(value: any) {
  const v = String(value ?? "").trim();
  return v || null;
}

function toIsoFromMillis(value: any) {
  const n = Number(value || 0);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(n).toISOString();
}

export async function GET(req: Request) {
  try {
    if (!authorized(req)) return unauthorized();

    const url = new URL(req.url);
    const firmId = String(url.searchParams.get("firmId") || "").trim();

    if (!firmId) {
      return NextResponse.json({ error: "firmId zorunlu." }, { status: 400 });
    }

    const supabase = getSupabase();

    const { data: employees, error: empError } = await supabase
      .from("employees")
      .select("id, firm_id, full_name, active")
      .eq("firm_id", firmId)
      .eq("active", true);

    if (empError) {
      return NextResponse.json(
        { error: "Çalışanlar alınamadı.", detail: empError.message },
        { status: 500 }
      );
    }

    const employeeIds = (employees || []).map((e: any) => e.id);

    if (employeeIds.length === 0) {
      return NextResponse.json({ success: true, count: 0, data: [] });
    }

    const { data: users, error: usersError } = await supabase
      .from("users")
      .select("id, employee_id, company_id")
      .in("employee_id", employeeIds);

    if (usersError) {
      return NextResponse.json(
        { error: "Kullanıcılar alınamadı.", detail: usersError.message },
        { status: 500 }
      );
    }

    const safeUsers = users || [];
    const userIds = safeUsers.map((u: any) => u.id);

    if (userIds.length === 0) {
      return NextResponse.json({ success: true, count: 0, data: [] });
    }

    const { data: assignments, error: assignmentError } = await supabase
      .from("training_assignments")
      .select(
        "id, user_id, training_id, status, started_at, completed_at, created_at, watch_completed, final_exam_passed"
      )
      .in("user_id", userIds)
      .order("created_at", { ascending: false });

    if (assignmentError) {
      return NextResponse.json(
        { error: "Eğitim atamaları alınamadı.", detail: assignmentError.message },
        { status: 500 }
      );
    }

    const trainingIds = Array.from(
      new Set((assignments || []).map((a: any) => a.training_id).filter(Boolean))
    );

    let trainings: any[] = [];

    if (trainingIds.length > 0) {
      const { data, error } = await supabase
        .from("trainings")
        .select("id, title, description, type, content_url, duration_minutes")
        .in("id", trainingIds);

      if (error) {
        return NextResponse.json(
          { error: "Eğitimler alınamadı.", detail: error.message },
          { status: 500 }
        );
      }

      trainings = data || [];
    }

    const userMap = Object.fromEntries(safeUsers.map((u: any) => [u.id, u]));
    const trainingMap = Object.fromEntries(trainings.map((t: any) => [t.id, t]));

    const result = (assignments || [])
  .filter((a: any) => {
    const training = trainingMap[a.training_id];
    const typeRaw = String(training?.type || "").toLowerCase();

    const isPortalTraining =
  
  typeRaw.includes("asenkron") ||
  typeRaw.includes("senkron");

    if (!isPortalTraining) return true;

    return (
      a.status === "completed" &&
      Boolean(a.watch_completed) === true &&
      Boolean(a.final_exam_passed) === true
    );
  })
  .map((a: any) => {
        const user = userMap[a.user_id];
        const training = trainingMap[a.training_id];

        if (!user || !training) return null;

        return {
          assignment_id: a.id,
          employee_remote_id: user.employee_id,
          user_id: a.user_id,
          training_id: a.training_id,
          title: training.title || "Eğitim",
          description: training.description || "",
          type: training.type || "asenkron",
          content_url: training.content_url || "",
          duration_minutes: training.duration_minutes || 0,
          status: a.status || "not_started",
          started_at: a.started_at,
          completed_at: a.completed_at,
          created_at: a.created_at,
          watch_completed: Boolean(a.watch_completed),
          final_exam_passed: Boolean(a.final_exam_passed),
        };
      })
      .filter(Boolean);

    return NextResponse.json({
      success: true,
      count: result.length,
      data: result,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Sunucu hatası.", detail: e?.message || null },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    if (!authorized(req)) return unauthorized();

    const body = await req.json();
    const records = Array.isArray(body?.records) ? body.records : [];
    const firstRecordFirmId =
    records.length > 0 ? String(records[0]?.firm_id || records[0]?.firmId || "").trim() : "";

   const firmId = String(body?.firmId || body?.firm_id || firstRecordFirmId || "").trim();

    if (!firmId) {
      return NextResponse.json({ error: "firmId zorunlu." }, { status: 400 });
    }

    if (records.length === 0) {
      return NextResponse.json({
        success: true,
        count: 0,
        results: [],
      });
    }

    const supabase = getSupabase();

    const { data: company, error: companyError } = await supabase
      .from("companies")
      .select("id")
      .eq("id", firmId)
      .maybeSingle();

    if (companyError || !company?.id) {
      return NextResponse.json({ error: "Geçersiz firmId." }, { status: 400 });
    }

    const results: any[] = [];

    for (const item of records) {
    const localId = String(item?.local_id ?? item?.localId ?? "").trim();
const remoteId = String(item?.remote_id ?? item?.remoteId ?? "").trim();

const employeeRemoteId = String(
  item?.employee_remote_id ||
    item?.employeeRemoteId ||
    item?.employee_id ||
    item?.employeeId ||
    ""
).trim();

const title = String(
  item?.training_title ||
    item?.trainingTitle ||
    item?.title ||
    item?.training_name ||
    ""
).trim();

const itemFirmId = String(item?.firm_id || item?.firmId || firmId).trim();
if (itemFirmId !== firmId) {
  results.push({ localId, remoteId: remoteId || null, success: false, error: "Kayıt firma kimliği istek firmasıyla eşleşmiyor." });
  continue;
}

const deleted =
  item?.deleted === true ||
  item?.is_deleted === true ||
  item?.isDeleted === true ||
  item?.delete === true;

if (deleted) {
  if (!remoteId) {
    results.push({
      localId,
      remoteId: null,
      success: false,
      error: "Silme için remoteId eksik.",
    });
    continue;
  }

  const { data: deleteCandidate } = await supabase
    .from("training_assignments")
    .select("id, user_id")
    .eq("id", remoteId)
    .maybeSingle();

  const { data: deleteUser } = deleteCandidate?.user_id
    ? await supabase.from("users").select("employee_id").eq("id", deleteCandidate.user_id).maybeSingle()
    : { data: null as any };

  const { data: deleteEmployee } = deleteUser?.employee_id
    ? await supabase.from("employees").select("id").eq("id", deleteUser.employee_id).eq("firm_id", firmId).maybeSingle()
    : { data: null as any };

  if (!deleteCandidate?.id || !deleteEmployee?.id) {
    results.push({ localId, remoteId, success: false, error: "Eğitim ataması bu firmaya ait değil." });
    continue;
  }

  const { error: deleteAssignmentError } = await supabase
    .from("training_assignments")
    .delete()
    .eq("id", remoteId);

  if (deleteAssignmentError) {
    results.push({
      localId,
      remoteId,
      success: false,
      error: deleteAssignmentError.message,
    });
    continue;
  }

  results.push({
    localId,
    remoteId,
    success: true,
    deleted: true,
    error: null,
  });

  continue;
}

      if (!employeeRemoteId || !title) {
        results.push({
          localId,
          remoteId: remoteId || null,
          success: false,
          error: "employeeRemoteId veya trainingTitle eksik.",
        });
        continue;
      }

      const typeRaw = String(
  item?.training_type ||
  item?.trainingType ||
  item?.type ||
  "ORGUN"
)
  .trim()
  .toUpperCase();

      const webType =
  typeRaw === "ASENKRON"
    ? "asenkron"
    : typeRaw === "SENKRON"
    ? "senkron"
    : typeRaw === "OZEL"
    ? "ozel"
    : "orgun";

      const isAppRecord = webType === "orgun" || webType === "ozel";

const status = isAppRecord
  ? "completed"
  : item?.completed === true
  ? "completed"
  : "not_started";

      const trainingPayload = {
  title,
  description: clean(item?.description) || "App üzerinden gelen eğitim kaydı.",
  type: webType,
  content_url: clean(item?.online_url || item?.onlineUrl),
  duration_minutes: Number(item?.duration_minutes || item?.durationMinutes || 0),
};

      let trainingId = "";
const assignmentRemoteId = remoteId;

if (false as boolean) {
        const { error: updateTrainingError } = await supabase
          .from("trainings")
          .update(trainingPayload)
          .eq("id", trainingId);

        if (updateTrainingError) {
          results.push({
            localId,
            remoteId: trainingId,
            success: false,
            error: updateTrainingError.message,
          });
          continue;
        }
      } else {
        const { data: existingTraining } = await supabase
  .from("trainings")
  .select("id")
  .eq("title", title)
  .eq("type", webType)
  .maybeSingle();

        if (existingTraining?.id) {
          trainingId = existingTraining.id;

          await supabase
            .from("trainings")
            .update(trainingPayload)
            .eq("id", trainingId);
        } else {
          const { data: newTraining, error: insertTrainingError } = await supabase
            .from("trainings")
            .insert([
  {
    ...trainingPayload,
  },
])
            .select("id")
            .single();

          if (insertTrainingError || !newTraining?.id) {
            results.push({
              localId,
              remoteId: null,
              success: false,
              error: insertTrainingError?.message || "Eğitim oluşturulamadı.",
            });
            continue;
          }

          trainingId = newTraining.id;
        }
      }

      let userRow: any = null;

const { data: ownedEmployee, error: ownedEmployeeError } = await supabase
  .from("employees")
  .select("id, firm_id, full_name, email, active")
  .eq("id", employeeRemoteId)
  .eq("firm_id", firmId)
  .maybeSingle();

if (ownedEmployeeError || !ownedEmployee?.id) {
  results.push({ localId, remoteId: remoteId || null, success: false, error: "Çalışan seçili firmaya ait değil." });
  continue;
}

const { data: foundUser, error: userError } = await supabase
  .from("users")
  .select("id, employee_id")
  .eq("employee_id", employeeRemoteId)
  .maybeSingle();

if (userError) {
  results.push({
    localId,
    remoteId: trainingId,
    success: false,
    error: userError.message,
  });
  continue;
}

userRow = foundUser;

if (!userRow?.id) {
  const { data: employeeRow, error: employeeError } = await supabase
    .from("employees")
    .select("id, firm_id, full_name, email, active")
    .eq("id", employeeRemoteId)
    .eq("firm_id", firmId)
    .maybeSingle();

  if (employeeError || !employeeRow?.id) {
    results.push({
      localId,
      remoteId: trainingId,
      success: false,
      error: "Çalışan web tarafında bulunamadı.",
    });
    continue;
  }

  const autoEmail =
    clean(employeeRow.email) ||
    `employee-${String(employeeRow.id).slice(0, 8)}@dsec.local`;

  const { data: newUser, error: createUserError } = await supabase
    .from("users")
    .insert([
      {
        full_name: employeeRow.full_name || "Eğitim Kullanıcısı",
        email: autoEmail,
        password: "123456",
        role: "training_user",
        company_id: firmId,
        employee_id: employeeRow.id,
        is_active: true,
        created_at: new Date().toISOString(),
      },
    ])
    .select("id, employee_id")
    .single();

  if (createUserError || !newUser?.id) {
    results.push({
      localId,
      remoteId: trainingId,
      success: false,
      error: createUserError?.message || "Eğitim kullanıcısı oluşturulamadı.",
    });
    continue;
  }


  userRow = newUser;
}

    const assignmentPayload = {
  user_id: userRow.id,
  training_id: trainingId,
  status,
  started_at: toIsoFromMillis(
    item?.started_at || item?.startedAt || item?.training_date
  ),
  completed_at: isAppRecord
    ? toIsoFromMillis(
        item?.completed_at || item?.completedAt || item?.training_date
      )
    : toIsoFromMillis(item?.completed_at || item?.completedAt),
  watch_completed: isAppRecord
    ? true
    : Boolean(item?.watch_completed || item?.watchCompleted),
  final_exam_passed: isAppRecord
    ? true
    : Boolean(item?.final_exam_passed || item?.finalExamPassed),
};
      let existingAssignment: any = null;
      let insertedAssignment: any = null;

if (assignmentRemoteId) {
  const { data } = await supabase
    .from("training_assignments")
    .select("id")
    .eq("id", assignmentRemoteId)
    .maybeSingle();

  existingAssignment = data;
}

if (!existingAssignment?.id) {
  const { data } = await supabase
    .from("training_assignments")
    .select("id")
    .eq("user_id", userRow.id)
    .eq("training_id", trainingId)
    .maybeSingle();

  existingAssignment = data;
}

      if (existingAssignment?.id) {
        const { error: updateAssignmentError } = await supabase
          .from("training_assignments")
          .update(assignmentPayload)
          .eq("id", existingAssignment.id);

        if (updateAssignmentError) {
          results.push({
            localId,
            remoteId: trainingId,
            success: false,
            error: updateAssignmentError.message,
          });
          continue;
        }
      } else {
const {
  data,
  error: insertAssignmentError,
} = await supabase
  .from("training_assignments")
  .insert([
    {
      ...assignmentPayload,
      created_at: new Date().toISOString(),
    },
  ])
  .select("id")
  .single();

insertedAssignment = data;
  
        if (insertAssignmentError) {
          results.push({
            localId,
            remoteId: trainingId,
            success: false,
            error: insertAssignmentError.message,
          });
          continue;
        }
      }

     results.push({
  localId,
  remoteId:
    existingAssignment?.id ||
    insertedAssignment?.id ||
    assignmentRemoteId ||
    trainingId,
  trainingId,
  success: true,
  error: null,
});
    }

    return NextResponse.json({
      success: true,
      count: results.length,
      results,
    });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Sunucu hatası.", detail: e?.message || null },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    if (!authorized(req)) return unauthorized();

    const url = new URL(req.url);
    const assignmentId = String(url.searchParams.get("assignmentId") || "").trim();
    const firmId = String(url.searchParams.get("firmId") || "").trim();

    if (!assignmentId || !firmId) {
      return NextResponse.json(
        { error: "assignmentId ve firmId zorunlu." },
        { status: 400 }
      );
    }

    const supabase = getSupabase();

    const { data: assignment, error: assignmentError } = await supabase
      .from("training_assignments")
      .select("id, user_id")
      .eq("id", assignmentId)
      .maybeSingle();

    if (assignmentError || !assignment?.id) {
      return NextResponse.json({ error: "Eğitim ataması bulunamadı." }, { status: 404 });
    }

    const { data: user } = await supabase
      .from("users")
      .select("employee_id")
      .eq("id", assignment.user_id)
      .maybeSingle();

    if (!user?.employee_id) {
      return NextResponse.json({ error: "Atamanın çalışan bağı bulunamadı." }, { status: 409 });
    }

    const { data: employee } = await supabase
      .from("employees")
      .select("id")
      .eq("id", user.employee_id)
      .eq("firm_id", firmId)
      .maybeSingle();

    if (!employee?.id) {
      return NextResponse.json({ error: "Bu atama seçili firmaya ait değil." }, { status: 403 });
    }

    const { error } = await supabase
      .from("training_assignments")
      .delete()
      .eq("id", assignmentId);

    if (error) {
      return NextResponse.json(
        { error: "Eğitim ataması silinemedi.", detail: error.message },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true, deletedAssignmentId: assignmentId, firmId });
  } catch (e: any) {
    return NextResponse.json(
      { error: "Sunucu hatası.", detail: e?.message || null },
      { status: 500 }
    );
  }
}
