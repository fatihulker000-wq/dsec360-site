import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";

function getSupabase() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, key);
}

type AssignmentRow = {
  id: string;
  user_id: string;
  training_id: string;
  status: "not_started" | "in_progress" | "completed" | null;
  watch_completed?: boolean | null;
  final_exam_passed?: boolean | null;
};

type TrainingRow = {
  id: string;
  title: string | null;
  type: string | null;
};

type UserRow = {
  id: string;
  full_name: string | null;
  email: string | null;
  company_id: string | null;
};

type CompanyRow = {
  id: string;
  name: string | null;
};

type RiskSummary = {
  low: number;
  medium: number;
  high: number;
  veryHigh: number;
};

function normalizeRiskLevel(value: unknown): keyof RiskSummary | null {
  const raw = String(value ?? "")
    .trim()
    .toLocaleUpperCase("tr-TR")
    .replaceAll("İ", "I")
    .replaceAll("Ğ", "G")
    .replaceAll("Ü", "U")
    .replaceAll("Ş", "S")
    .replaceAll("Ö", "O")
    .replaceAll("Ç", "C")
    .replace(/[\s-]+/g, "_");

  if (!raw) return null;

  if (
    raw.includes("VERY_HIGH") ||
    raw.includes("INTOLERABLE") ||
    raw.includes("COK_YUKSEK") ||
    raw.includes("KRITIK")
  ) {
    return "veryHigh";
  }

  if (raw.includes("HIGH") || raw.includes("YUKSEK")) {
    return "high";
  }

  if (raw.includes("MEDIUM") || raw.includes("ORTA")) {
    return "medium";
  }

  if (raw.includes("LOW") || raw.includes("DUSUK")) {
    return "low";
  }

  return null;
}

function addRiskLevel(summary: RiskSummary, value: unknown) {
  const level = normalizeRiskLevel(value);
  if (level) summary[level] += 1;
}

function addRiskScore(
  summary: RiskSummary,
  scoreValue: unknown,
  source: "MATRIX" | "FINE_KINNEY"
) {
  const score = Number(scoreValue);
  if (!Number.isFinite(score)) return;

  if (source === "MATRIX") {
    if (score >= 20) summary.veryHigh += 1;
    else if (score >= 15) summary.high += 1;
    else if (score >= 8) summary.medium += 1;
    else summary.low += 1;
    return;
  }

  if (score > 400) summary.veryHigh += 1;
  else if (score >= 200) summary.high += 1;
  else if (score >= 70) summary.medium += 1;
  else summary.low += 1;
}

function isOnlineTraining(training?: TrainingRow) {
  const type = String(training?.type || "").toLowerCase();

  return (
    type.includes("online") ||
    type.includes("asenkron") ||
    type.includes("senkron")
  );
}

function isTrainingCompleted(row: AssignmentRow, training?: TrainingRow) {
  if (isOnlineTraining(training)) {
    return (
      row.status === "completed" &&
      row.watch_completed === true &&
      row.final_exam_passed === true
    );
  }

  return row.status === "completed";
}

export async function GET(request: Request) {
  try {
    const cookieStore = await cookies();
    const adminAuth =
      cookieStore.get("dsec_admin_auth")?.value ||
      cookieStore.get("dsec_user_auth")?.value;
    const adminRole =
      cookieStore.get("dsec_admin_role")?.value ||
      cookieStore.get("dsec_user_role")?.value;
    const companyIdFromCookie = String(
      cookieStore.get("dsec_company_id")?.value || ""
    ).trim();

    const isAllowedRole =
      adminRole === "super_admin" ||
      adminRole === "company_admin" ||
      adminRole === "demo_user";

    const isCompanyScoped =
      adminRole === "company_admin" || adminRole === "demo_user";

    if (adminAuth !== "ok" || !isAllowedRole) {
      return NextResponse.json(
        { error: "Yetkisiz erişim." },
        { status: 401 }
      );
    }

    if (isCompanyScoped && !companyIdFromCookie) {
      return NextResponse.json(
        { error: "Firma yöneticisi için firma bilgisi bulunamadı." },
        { status: 403 }
      );
    }

    const supabase = getSupabase();

    const { data: assignments, error: assignmentsError } = await supabase
      .from("training_assignments")
      .select("id, user_id, training_id, status, watch_completed, final_exam_passed")
      .returns<AssignmentRow[]>();

    if (assignmentsError) {
      return NextResponse.json(
        {
          error: "Eğitim atamaları alınamadı.",
          detail: assignmentsError.message,
        },
        { status: 500 }
      );
    }

    const allAssignmentRows = assignments || [];

    const trainingIds = Array.from(
      new Set(allAssignmentRows.map((a) => a.training_id).filter(Boolean))
    );

    const userIds = Array.from(
      new Set(allAssignmentRows.map((a) => a.user_id).filter(Boolean))
    );

    let trainingsMap: Record<string, TrainingRow> = {};
    let usersMap: Record<string, UserRow> = {};
    let companyMap: Record<string, string> = {};

    if (trainingIds.length > 0) {
      const { data: trainings, error: trainingsError } = await supabase
        .from("trainings")
        .select("id, title, type")
        .in("id", trainingIds)
        .returns<TrainingRow[]>();

      if (trainingsError) {
        return NextResponse.json(
          {
            error: "Eğitim detayları alınamadı.",
            detail: trainingsError.message,
          },
          { status: 500 }
        );
      }

      trainingsMap = Object.fromEntries((trainings || []).map((t) => [t.id, t]));
    }

    if (userIds.length > 0) {
      let userQuery = supabase
        .from("users")
        .select("id, full_name, email, company_id")
        .in("id", userIds);

      if (isCompanyScoped) {
        userQuery = userQuery.eq("company_id", companyIdFromCookie);
      }

      const { data: users, error: usersError } = await userQuery.returns<UserRow[]>();

      if (usersError) {
        return NextResponse.json(
          {
            error: "Kullanıcı detayları alınamadı.",
            detail: usersError.message,
          },
          { status: 500 }
        );
      }

      usersMap = Object.fromEntries((users || []).map((u) => [u.id, u]));

     let companiesQuery = supabase
  .from("companies")
  .select("id, name");

if (isCompanyScoped) {
  companiesQuery = companiesQuery.eq("id", companyIdFromCookie);
}

const { data: companies, error: companiesError } = await companiesQuery.returns<CompanyRow[]>();

if (companiesError) {
  return NextResponse.json(
    {
      error: "Firma detayları alınamadı.",
      detail: companiesError.message,
    },
    { status: 500 }
  );
}

companyMap = Object.fromEntries(
  (companies || []).map((c) => [
    String(c.id || "").trim(),
    String(c.name || "Firma Yok").trim() || "Firma Yok",
  ])
);
    }

    const allowedUserIds = new Set(Object.keys(usersMap));
    const assignmentRows = allAssignmentRows.filter((row) =>
      allowedUserIds.has(row.user_id)
    );

    const trainingStatsMap = new Map<
      string,
      {
        id: string;
        title: string;
        assigned_count: number;
        not_started_count: number;
        in_progress_count: number;
        completed_count: number;
      }
    >();

    let totalAssigned = 0;
    let totalCompleted = 0;
    let totalInProgress = 0;
    let totalNotStarted = 0;

    for (const row of assignmentRows) {
      const trainingId = row.training_id;
      if (!trainingId) continue;

      const current = trainingStatsMap.get(trainingId) || {
        id: trainingId,
        title: trainingsMap[trainingId]?.title || "Eğitim",
        assigned_count: 0,
        not_started_count: 0,
        in_progress_count: 0,
        completed_count: 0,
      };

      current.assigned_count += 1;
      totalAssigned += 1;

      const isCompleted = isTrainingCompleted(row, trainingsMap[row.training_id]);

      if (isCompleted) {
        current.completed_count += 1;
        totalCompleted += 1;
      } else if (row.status === "in_progress") {
        current.in_progress_count += 1;
        totalInProgress += 1;
      } else {
        current.not_started_count += 1;
        totalNotStarted += 1;
      }

      trainingStatsMap.set(trainingId, current);
    }

    const riskyUsers = assignmentRows
      .filter((row) => {
        const isCompleted = isTrainingCompleted(row, trainingsMap[row.training_id]);
        return !isCompleted && row.status !== "in_progress";
      })
      .map((row) => {
        const rawCompanyId = String(usersMap[row.user_id]?.company_id || "").trim();

        return {
          assignment_id: row.id,
          user_id: row.user_id,
          training_id: row.training_id,
          full_name: usersMap[row.user_id]?.full_name || "Kullanıcı",
          email: usersMap[row.user_id]?.email || "",
          company_id: companyMap[rawCompanyId] || "Firma Yok",
          training_title: trainingsMap[row.training_id]?.title || "Eğitim",
          status: "not_started" as const,
        };
      });

    const inProgressUsers = assignmentRows
      .filter((row) => {
  const isCompleted = isTrainingCompleted(row, trainingsMap[row.training_id]);

  return row.status === "in_progress" && !isCompleted;
})
      .map((row) => {
        const rawCompanyId = String(usersMap[row.user_id]?.company_id || "").trim();

        return {
          assignment_id: row.id,
          user_id: row.user_id,
          training_id: row.training_id,
          full_name: usersMap[row.user_id]?.full_name || "Kullanıcı",
          email: usersMap[row.user_id]?.email || "",
          company_id: companyMap[rawCompanyId] || "Firma Yok",
          training_title: trainingsMap[row.training_id]?.title || "Eğitim",
          status: "in_progress" as const,
        };
      });

    const completedUsers = assignmentRows
  .filter((row) => isTrainingCompleted(row, trainingsMap[row.training_id]))
      .map((row) => {
        const rawCompanyId = String(usersMap[row.user_id]?.company_id || "").trim();

        return {
          assignment_id: row.id,
          user_id: row.user_id,
          training_id: row.training_id,
          full_name: usersMap[row.user_id]?.full_name || "Kullanıcı",
          email: usersMap[row.user_id]?.email || "",
          company_id: companyMap[rawCompanyId] || "Firma Yok",
          training_title: trainingsMap[row.training_id]?.title || "Eğitim",
          status: "completed" as const,
        };
      });

    const trainings = Array.from(trainingStatsMap.values()).sort(
      (a, b) => b.assigned_count - a.assigned_count
    );

    const completionRate = totalAssigned
      ? Number(((totalCompleted / totalAssigned) * 100).toFixed(2))
      : 0;

    const inProgressRate = totalAssigned
      ? Number(((totalInProgress / totalAssigned) * 100).toFixed(2))
      : 0;

    const riskRate = totalAssigned
      ? Number(((totalNotStarted / totalAssigned) * 100).toFixed(2))
      : 0;

    const riskStatus =
      totalNotStarted > 20
        ? "KRITIK"
        : totalNotStarted > 10
        ? "ORTA"
        : "IYI";

    const companyRiskMap = new Map<string, number>();
    riskyUsers.forEach((u) => {
      const key = u.company_id || "Firma Yok";
      companyRiskMap.set(key, (companyRiskMap.get(key) || 0) + 1);
    });

    const companyDistribution = Array.from(companyRiskMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    const monthlyTrend = [
      { label: "Tamamlandı", value: totalCompleted },
      { label: "Devam", value: totalInProgress },
      { label: "Başlamadı", value: totalNotStarted },
    ];

const upcomingTrainings = trainings
  .slice(0, 5)
  .map((training) => ({
    id: training.id,
    title: training.title,
    company: isCompanyScoped ? companyMap[companyIdFromCookie] || "Firma" : "Genel",
    date: new Date().toISOString(),
  }));

const activities = [
  ...completedUsers.slice(0, 3).map((user) => ({
    id: `completed-${user.assignment_id}`,
    type: "training_completed",
    title: `${user.full_name} eğitimi tamamladı`,
    company: user.company_id,
    created_at: new Date().toISOString(),
  })),
  ...riskyUsers.slice(0, 3).map((user) => ({
    id: `training-risk-${user.assignment_id}`,
    type: "training_risk",
    title: `${user.full_name} eğitime başlamadı`,
    company: user.company_id,
    created_at: new Date().toISOString(),
  })),
];


    // ============================================================
    // GERÇEK RİSK ÖZETİ
    // 5x5: risk_items
    // Fine-Kinney: fine_kinney_risks
    // ============================================================

    const requestUrl = new URL(request.url);
    const requestedFirm = String(
      requestUrl.searchParams.get("firm") ||
      requestUrl.searchParams.get("firmId") ||
      ""
    ).trim();

    let selectedRiskCompanyId = "";

    if (isCompanyScoped) {
      selectedRiskCompanyId = companyIdFromCookie;
    } else if (requestedFirm && requestedFirm.toLowerCase() !== "all") {
      // Önce doğrudan company id olarak kontrol et.
      if (companyMap[requestedFirm]) {
        selectedRiskCompanyId = requestedFirm;
      } else {
        const requestedKey = requestedFirm
          .trim()
          .toLocaleLowerCase("tr-TR")
          .replace(/\s+/g, " ");

        selectedRiskCompanyId =
          Object.entries(companyMap).find(([, name]) => {
            const nameKey = String(name || "")
              .trim()
              .toLocaleLowerCase("tr-TR")
              .replace(/\s+/g, " ");

            return nameKey === requestedKey;
          })?.[0] || "";
      }
    }

    type DashboardRiskSummary = {
      low: number;
      medium: number;
      high: number;
      veryHigh: number;
    };

    const riskSummary: DashboardRiskSummary = {
      low: 0,
      medium: 0,
      high: 0,
      veryHigh: 0,
    };

    const matrixLevelFromScore = (score: number) => {
      if (score >= 20) return "VERY_HIGH";
      if (score >= 15) return "HIGH";
      if (score >= 8) return "MEDIUM";
      return "LOW";
    };

    const fineKinneyLevelFromScore = (score: number) => {
      if (score >= 200) return "VERY_HIGH";
      if (score >= 70) return "HIGH";
      if (score >= 20) return "MEDIUM";
      return "LOW";
    };

    let matrixRiskQuery = supabase
      .from("risk_items")
      .select("score, is_deleted")
      .eq("is_deleted", false);

    let fineKinneyRiskQuery = supabase
      .from("fine_kinney_risks")
      .select("score, is_deleted")
      .eq("is_deleted", false);

    if (selectedRiskCompanyId) {
      matrixRiskQuery = matrixRiskQuery.eq(
        "company_id",
        selectedRiskCompanyId
      );

      fineKinneyRiskQuery = fineKinneyRiskQuery.eq(
        "company_id",
        selectedRiskCompanyId
      );
    }

    const [matrixRiskResult, fineKinneyRiskResult] =
      await Promise.all([
        matrixRiskQuery,
        fineKinneyRiskQuery,
      ]);

    if (matrixRiskResult.error) {
      console.error(
        "training-dashboard risk_items error:",
        matrixRiskResult.error
      );
    } else {
      for (const row of matrixRiskResult.data || []) {
        const score = Number(row.score || 0);
        const level = matrixLevelFromScore(score);

        if (level === "VERY_HIGH") riskSummary.veryHigh += 1;
        else if (level === "HIGH") riskSummary.high += 1;
        else if (level === "MEDIUM") riskSummary.medium += 1;
        else riskSummary.low += 1;
      }
    }

    if (fineKinneyRiskResult.error) {
      console.error(
        "training-dashboard fine_kinney_risks error:",
        fineKinneyRiskResult.error
      );
    } else {
      for (const row of fineKinneyRiskResult.data || []) {
        const score = Number(row.score || 0);
        const level = fineKinneyLevelFromScore(score);

        if (level === "VERY_HIGH") riskSummary.veryHigh += 1;
        else if (level === "HIGH") riskSummary.high += 1;
        else if (level === "MEDIUM") riskSummary.medium += 1;
        else riskSummary.low += 1;
      }
    }

const doraSummary = {
  level:
    riskRate >= 60 ? "Kritik" : riskRate >= 30 ? "Orta" : "İyi",
  message:
    riskRate >= 60
      ? "Eğitim riski yüksek. Başlamayan eğitimler için hızlı aksiyon önerilir."
      : riskRate >= 30
      ? "Eğitim riski orta seviyede. Devam eden ve başlamayan eğitimler izlenmelidir."
      : "Eğitim görünümü kontrollü. Tamamlama oranı sürdürülebilir seviyededir.",
} as const;

  return NextResponse.json({
  success: true,
  trainings,
  risky_users: riskyUsers,
  in_progress_users: inProgressUsers,
  completed_users: completedUsers,
  company_distribution: companyDistribution,
  company_list: Object.values(companyMap).sort((a, b) =>
    a.localeCompare(b, "tr")
  ),
  trend: monthlyTrend,
  summary: {
        total_assignments: totalAssigned,
        completed_count: totalCompleted,
        in_progress_count: totalInProgress,
        not_started_count: totalNotStarted,
        completion_rate: completionRate,
        in_progress_rate: inProgressRate,
        risk_rate: riskRate,
        risk_status: riskStatus,
      },
      activities,
  upcoming_trainings: upcomingTrainings,
  risk_summary: riskSummary,
    dora_summary: doraSummary,
    });
  } catch (err) {
    console.error("admin training dashboard route error:", err);
    return NextResponse.json(
      {
        error: "Sunucu hatası.",
        detail: String(err),
      },
      { status: 500 }
    );
  }
}