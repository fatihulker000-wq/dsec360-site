import { createClient } from "@supabase/supabase-js";
import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";

function getSupabase() {
  return createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

type AccessContext = {
  allowed: boolean;
  role: string;
  companyId: string;
  companyScoped: boolean;
};

async function getAccessContext(): Promise<AccessContext> {
  const cookieStore = await cookies();

  const auth = String(
    cookieStore.get("dsec_admin_auth")?.value ||
      cookieStore.get("dsec_user_auth")?.value ||
      ""
  ).trim();

  const role = String(
    cookieStore.get("dsec_admin_role")?.value ||
      cookieStore.get("dsec_user_role")?.value ||
      ""
  ).trim();

  const companyId = String(
    cookieStore.get("dsec_company_id")?.value || ""
  ).trim();

  const allowedRoles = [
    "admin",
    "super_admin",
    "company_admin",
    "demo_user",
  ];

  const companyScoped =
    role === "company_admin" || role === "demo_user";

  return {
    allowed:
      auth === "ok" &&
      allowedRoles.includes(role) &&
      (!companyScoped || Boolean(companyId)),
    role,
    companyId,
    companyScoped,
  };
}

async function checkWriteAdmin() {
  const access = await getAccessContext();

  return (
    access.allowed &&
    (access.role === "admin" || access.role === "super_admin")
  );
}

type CompanyRow = {
  id: string;
  name: string | null;
  local_firm_id: number | null;
  yetkili: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;

  // 🔥 YENİ ALANLAR
  calisan_sayisi: number | null;
  nace_kodu: string | null;
  tehlike_sinifi: string | null;
  sgk_sicil_no: string | null;
  sektor: string | null;
  isg_uzmani: string | null;
  isyeri_hekimi: string | null;
  dsp: string | null;

  created_at: string | null;
  is_active: boolean | null;
};

export async function GET() {
  try {
    const access = await getAccessContext();

if (!access.allowed) {
  return NextResponse.json(
    { error: "Yetkisiz erişim veya firma bilgisi eksik." },
    { status: 401 }
  );
}

const supabase = getSupabase();

let companyQuery = supabase
  .from("companies")
  .select(`
        id,
        name,
        local_firm_id,
        yetkili,
        phone,
        email,
        address,
        calisan_sayisi,
        nace_kodu,
        tehlike_sinifi,
        sgk_sicil_no,
        sektor,
        isg_uzmani,
        isyeri_hekimi,
        dsp,
        created_at,
        is_active
        `);

if (access.companyScoped) {
  companyQuery = companyQuery.eq("id", access.companyId);
}

const { data, error } = await companyQuery.order(
  "created_at",
  { ascending: false }
);

    if (error) {
      console.error("companies GET error:", error);
      return NextResponse.json({ error: "Firmalar alınamadı." }, { status: 500 });
    }

    let allEmployees: Array<{
  id: string;
  firm_id: string | null;
  active: boolean | null;
}> = [];

let from = 0;
const step = 1000;

while (true) {
  let employeeQuery = supabase
  .from("employees")
  .select("id, firm_id, active");

if (access.companyScoped) {
  employeeQuery = employeeQuery.eq("firm_id", access.companyId);
}

const {
  data: employeesPage,
  error: employeeCountError,
} = await employeeQuery.range(from, from + step - 1);

  if (employeeCountError) {
    console.error("employees count error:", employeeCountError);
    break;
  }

  const rows = employeesPage || [];
  allEmployees = [...allEmployees, ...rows];

  if (rows.length < step) break;

  from += step;
}

const counts: Record<string, number> = {};

allEmployees.forEach((emp) => {
  if (!emp.firm_id) return;
  if (emp.active === false) return;

  counts[emp.firm_id] = (counts[emp.firm_id] || 0) + 1;
});

    const normalized = ((data || []) as CompanyRow[]).map((item) => ({
      id: String(item.id),
      name: String(item.name || "").trim(),
      local_firm_id: item.local_firm_id ?? null,
      localId: item.local_firm_id ?? null,
      yetkili: item.yetkili?.trim() || null,
      phone: item.phone?.trim() || null,
      email: item.email?.trim() || null,
      address: item.address?.trim() || null,

      // 🔥 YENİ ALANLAR
      calisan_sayisi: counts[String(item.id)] || 0,
      nace_kodu: item.nace_kodu ?? "",
      tehlike_sinifi: item.tehlike_sinifi ?? "",
      sgk_sicil_no: item.sgk_sicil_no ?? "",
      sektor: item.sektor ?? "",
      isg_uzmani: item.isg_uzmani ?? "",
      isyeri_hekimi: item.isyeri_hekimi ?? "",
      dsp: item.dsp ?? "",

      created_at: item.created_at || null,
      is_active: item.is_active ?? true,
      user_count: counts[String(item.id)] || 0,
    }));

    return NextResponse.json({ data: normalized });

  } catch (error) {
    console.error("companies GET genel hata:", error);
    return NextResponse.json({ error: "Sunucu hatası oluştu." }, { status: 500 });
  }
}

// ======================
// POST
// ======================
export async function POST(req: NextRequest) {
  try {
    const allowed = await checkWriteAdmin();
    if (!allowed) {
      return NextResponse.json({ error: "Yetkisiz erişim." }, { status: 401 });
    }

    const body = await req.json();

    const supabase = getSupabase();

    const { error } = await supabase.from("companies").insert({
      name: body.name,
      local_firm_id: body.local_firm_id ?? null,
      yetkili: body.yetkili || null,
      phone: body.phone || null,
      email: body.email || null,
      address: body.address || null,

      // 🔥 YENİ ALANLAR
      calisan_sayisi: body.calisan_sayisi ?? 0,
      nace_kodu: body.nace_kodu || null,
      tehlike_sinifi: body.tehlike_sinifi || null,
      sgk_sicil_no: body.sgk_sicil_no || null,
      sektor: body.sektor || null,
      isg_uzmani: body.isg_uzmani || null,
      isyeri_hekimi: body.isyeri_hekimi || null,
      dsp: body.dsp || null,

      is_active: true,
    });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });

  } catch {
    return NextResponse.json({ error: "Sunucu hatası" }, { status: 500 });
  }
}

// ======================
// PUT
// ======================
export async function PUT(req: NextRequest) {
  try {
    const allowed = await checkWriteAdmin();
    if (!allowed) {
      return NextResponse.json({ error: "Yetkisiz erişim." }, { status: 401 });
    }

    const body = await req.json();

    const supabase = getSupabase();

    const { error } = await supabase
      .from("companies")
      .update({
        name: body.name,
        local_firm_id: body.local_firm_id ?? null,
        yetkili: body.yetkili || null,
        phone: body.phone || null,
        email: body.email || null,
        address: body.address || null,

        // 🔥 YENİ ALANLAR
        calisan_sayisi: body.calisan_sayisi ?? 0,
        nace_kodu: body.nace_kodu || null,
        tehlike_sinifi: body.tehlike_sinifi || null,
        sgk_sicil_no: body.sgk_sicil_no || null,
        sektor: body.sektor || null,
        isg_uzmani: body.isg_uzmani || null,
        isyeri_hekimi: body.isyeri_hekimi || null,
        dsp: body.dsp || null,

        is_active: body.is_active,
      })
      .eq("id", body.id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });

  } catch {
    return NextResponse.json({ error: "Sunucu hatası" }, { status: 500 });
  }
}

// ======================
// DELETE / PASİFE ALMA
// ======================
export async function DELETE(req: NextRequest) {
  try {
    const allowed = await checkWriteAdmin();

    if (!allowed) {
      return NextResponse.json(
        {
          error: "Yetkisiz erişim.",
        },
        {
          status: 401,
        }
      );
    }

    const id =
      req.nextUrl.searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        {
          error: "Firma ID eksik.",
        },
        {
          status: 400,
        }
      );
    }

    const supabase = getSupabase();

    // Önce firma kaydını bul.
    const {
      data: company,
      error: companyError,
    } = await supabase
      .from("companies")
      .select("id, name, is_active")
      .eq("id", id)
      .maybeSingle();

    if (companyError) {
      return NextResponse.json(
        {
          error: companyError.message,
        },
        {
          status: 500,
        }
      );
    }

    if (!company) {
      return NextResponse.json(
        {
          error: "Firma bulunamadı.",
        },
        {
          status: 404,
        }
      );
    }

    const normalizedName =
      String(company.name || "")
        .trim()
        .toLocaleLowerCase("tr-TR");

    const isDemoCompany =
      normalizedName.includes(
        "d-sec demo lojistik"
      );

    // Demo firma silinemez veya pasife alınamaz.
    if (isDemoCompany) {
      return NextResponse.json(
        {
          error:
            "D-SEC Demo Lojistik ve Depolama A.Ş. korumalı demo firmasıdır. Silinemez veya pasife alınamaz.",
        },
        {
          status: 409,
        }
      );
    }

    // Fiziksel silme yapılmaz.
    const {
      error: updateError,
    } = await supabase
      .from("companies")
      .update({
        is_active: false,
      })
      .eq("id", id);

    if (updateError) {
      return NextResponse.json(
        {
          error: updateError.message,
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      success: true,
      message:
        "Firma silinmedi; pasif duruma alındı.",
    });
  } catch (errorValue: unknown) {
    console.error(
      "companies DELETE error:",
      errorValue
    );

    return NextResponse.json(
      {
        error:
          errorValue instanceof Error
            ? errorValue.message
            : "Sunucu hatası",
      },
      {
        status: 500,
      }
    );
  }
}