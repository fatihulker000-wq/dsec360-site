"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type TrainingItem = {
  id: string;
  status?: "not_started" | "in_progress" | "completed";
  watch_completed?: boolean | null;
  pre_exam_completed?: boolean | null;
  final_exam_passed?: boolean | null;
  final_exam_score?: number | null;
  final_exam_attempts?: number | null;
  training?: {
    title?: string;
    description?: string;
    type?: string | null;
  } | null;
};

function normalizeType(type?: string | null) {
  const value = (type || "").trim().toLowerCase();
  if (value === "senkron") return "senkron";
  if (value === "asenkron") return "asenkron";
  return "asenkron";
}

function normalizeFinalScore(score?: number | null) {
  if (score === null || score === undefined) return null;

  const numeric = Number(score);
  if (!Number.isFinite(numeric)) return null;

  const clamped = Math.max(0, Math.min(100, numeric));

  return Math.round(clamped / 10) * 10;
}

function shouldShowFinalScore(params: {
  final_exam_score?: number | null;
  final_exam_attempts?: number | null;
  final_exam_passed?: boolean | null;
  status?: "not_started" | "in_progress" | "completed";
}) {
  const attempts = Number(params.final_exam_attempts || 0);
  const passed = params.final_exam_passed === true;
  const completed = params.status === "completed";
  const hasRawScore =
    params.final_exam_score !== null && params.final_exam_score !== undefined;

  if (!hasRawScore) return false;

  return attempts > 0 || passed || completed;
}

function TrainingListSkeleton({
  loggingOut,
  onLogout,
}: {
  loggingOut: boolean;
  onLogout: () => void;
}) {
  const cardSkeletons = Array.from({ length: 6 });

  return (
    <main
      style={{
        padding: "40px",
        fontFamily: "Arial",
        background: "#f8fafc",
        minHeight: "100vh",
      }}
    >
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "12px",
            alignItems: "center",
            marginBottom: "20px",
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              width: "220px",
              height: "34px",
              borderRadius: "10px",
              background: "#e5e7eb",
            }}
          />

          <button
            type="button"
            onClick={onLogout}
            disabled={loggingOut}
            style={{
              padding: "12px 18px",
              borderRadius: "10px",
              border: "none",
              background: loggingOut ? "#9ca3af" : "#111827",
              color: "#fff",
              fontWeight: 700,
              cursor: loggingOut ? "not-allowed" : "pointer",
            }}
          >
            {loggingOut ? "Çıkış yapılıyor..." : "Çıkış Yap"}
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "16px",
          }}
        >
          {cardSkeletons.map((_, index) => (
            <div
              key={index}
              style={{
                background: "#ffffff",
                border: "1px solid #e5e7eb",
                borderRadius: "16px",
                padding: "18px",
                boxShadow: "0 8px 24px rgba(0,0,0,0.06)",
              }}
            >
              <div
                style={{
                  width: "68%",
                  height: "24px",
                  borderRadius: "8px",
                  background: "#e5e7eb",
                  marginBottom: "14px",
                }}
              />

              <div
                style={{
                  width: "100%",
                  height: "14px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  marginBottom: "10px",
                }}
              />
              <div
                style={{
                  width: "88%",
                  height: "14px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  marginBottom: "10px",
                }}
              />
              <div
                style={{
                  width: "72%",
                  height: "14px",
                  borderRadius: "8px",
                  background: "#f1f5f9",
                  marginBottom: "18px",
                }}
              />

              <div
                style={{
                  display: "flex",
                  gap: "8px",
                  flexWrap: "wrap",
                  marginBottom: "18px",
                }}
              >
                {Array.from({ length: 4 }).map((__, chipIndex) => (
                  <div
                    key={chipIndex}
                    style={{
                      width: chipIndex === 0 ? "78px" : chipIndex === 1 ? "120px" : chipIndex === 2 ? "115px" : "90px",
                      height: "28px",
                      borderRadius: "999px",
                      background: "#f3f4f6",
                      border: "1px solid #e5e7eb",
                    }}
                  />
                ))}
              </div>

              <div
                style={{
                  width: "100%",
                  height: "46px",
                  borderRadius: "10px",
                  background: "#dbeafe",
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}

export default function TrainingListPage() {
  const router = useRouter();
  const [items, setItems] = useState<TrainingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    try {
      setLoggingOut(true);

      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      }).catch(() => null);

      await fetch("/api/admin/logout", {
        method: "POST",
        credentials: "include",
      }).catch(() => null);
    } finally {
      window.location.href = "/login";
    }
  };

  useEffect(() => {
    const fetchTrainings = async () => {
      try {
        setLoading(true);
        setError("");

        const res = await fetch("/api/training/my", {
          method: "GET",
          cache: "no-store",
          credentials: "include",
        });

        if (res.status === 401) {
          window.location.href = "/login";
          return;
        }

        if (!res.ok) {
          setError(`API hata verdi: ${res.status}`);
          setItems([]);
          return;
        }

        const json = await res.json();

        if (!json || !Array.isArray(json.data)) {
          setError("Eğitim verisi bulunamadı.");
          setItems([]);
          return;
        }

        setItems(json.data);
      } catch (err) {
        console.error("training list fetch hatası:", err);
        setError("Bağlantı hatası oluştu.");
        setItems([]);
      } finally {
        setLoading(false);
      }
    };

    void fetchTrainings();
  }, []);

  if (loading) {
    return (
      <TrainingListSkeleton
        loggingOut={loggingOut}
        onLogout={handleLogout}
      />
    );
  }

  if (error) {
    return (
      <main
        style={{
          padding: "40px",
          fontFamily: "Arial",
          background: "#f8fafc",
          minHeight: "100vh",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "12px",
            marginBottom: "24px",
          }}
        >
          <h1 style={{ margin: 0 }}>Eğitim Portalı</h1>

          <button
            type="button"
            onClick={handleLogout}
            disabled={loggingOut}
            style={{
              padding: "12px 18px",
              borderRadius: "10px",
              border: "none",
              background: loggingOut ? "#9ca3af" : "#111827",
              color: "#fff",
              fontWeight: 700,
              cursor: loggingOut ? "not-allowed" : "pointer",
            }}
          >
            {loggingOut ? "Çıkış yapılıyor..." : "Çıkış Yap"}
          </button>
        </div>

        <h1>Hata</h1>
        <p>{error}</p>
      </main>
    );
  }

  if (items.length === 0) {
    return (
      <main
        style={{
          padding: "40px",
          fontFamily: "Arial",
          background: "#f8fafc",
          minHeight: "100vh",
        }}
      >
        <div
          style={{
            maxWidth: "1100px",
            margin: "0 auto",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "12px",
            marginBottom: "24px",
          }}
        >
          <h1 style={{ margin: 0 }}>Eğitim Portalı</h1>

          <button
            type="button"
            onClick={handleLogout}
            disabled={loggingOut}
            style={{
              padding: "12px 18px",
              borderRadius: "10px",
              border: "none",
              background: loggingOut ? "#9ca3af" : "#111827",
              color: "#fff",
              fontWeight: 700,
              cursor: loggingOut ? "not-allowed" : "pointer",
            }}
          >
            {loggingOut ? "Çıkış yapılıyor..." : "Çıkış Yap"}
          </button>
        </div>

        <p>Size atanmış eğitim bulunamadı.</p>
      </main>
    );
  }

  return (
    <main
      style={{
        padding: "40px",
        fontFamily: "Arial",
        background: "#f8fafc",
        minHeight: "100vh",
      }}
    >
      <div style={{ maxWidth: "1100px", margin: "0 auto" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: "12px",
            alignItems: "center",
            marginBottom: "20px",
            flexWrap: "wrap",
          }}
        >
          <h1 style={{ margin: 0 }}>Eğitimlerim</h1>

          <button
            type="button"
            onClick={handleLogout}
            disabled={loggingOut}
            style={{
              padding: "12px 18px",
              borderRadius: "10px",
              border: "none",
              background: loggingOut ? "#9ca3af" : "#111827",
              color: "#fff",
              fontWeight: 700,
              cursor: loggingOut ? "not-allowed" : "pointer",
            }}
          >
            {loggingOut ? "Çıkış yapılıyor..." : "Çıkış Yap"}
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "16px",
          }}
        >
          {items.map((item) => {
            const title = item.training?.title || "Eğitim";
            const description =
              item.training?.description || "Açıklama bulunmuyor.";
            const type = normalizeType(item.training?.type);

            const completed = item.final_exam_passed === true;
            const videoCompleted =
              item.status === "completed" || item.watch_completed === true;

            const finalAttempts = Number(item.final_exam_attempts || 0);
            const finalAttemptsLeft = Math.max(0, 3 - finalAttempts);

            const finalScore = normalizeFinalScore(item.final_exam_score);
            const showFinalScore = shouldShowFinalScore({
              final_exam_score: item.final_exam_score,
              final_exam_attempts: item.final_exam_attempts,
              final_exam_passed: item.final_exam_passed,
              status: item.status,
            });

            return (
              <div
                key={item.id}
                style={{
                  background: "#ffffff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "16px",
                  padding: "18px",
                  boxShadow: "0 8px 24px rgba(0,0,0,0.06)",
                }}
              >
                <h3 style={{ marginTop: 0, marginBottom: "10px" }}>{title}</h3>

                <p
                  style={{
                    color: "#4b5563",
                    lineHeight: 1.6,
                    minHeight: "48px",
                  }}
                >
                  {description}
                </p>

                <div
                  style={{
                    display: "flex",
                    gap: "8px",
                    flexWrap: "wrap",
                    marginTop: "12px",
                    marginBottom: "16px",
                  }}
                >
                  <span
                    style={{
                      padding: "6px 10px",
                      borderRadius: "999px",
                      background: "#f9fafb",
                      border: "1px solid #e5e7eb",
                      fontSize: "12px",
                      fontWeight: 700,
                    }}
                  >
                    Tür: {type}
                  </span>

                  <span
                    style={{
                      padding: "6px 10px",
                      borderRadius: "999px",
                      background: completed
                        ? "#dcfce7"
                        : videoCompleted
                        ? "#ecfccb"
                        : "#eff6ff",
                      border: completed
                        ? "1px solid #86efac"
                        : videoCompleted
                        ? "1px solid #bef264"
                        : "1px solid #bfdbfe",
                      color: completed
                        ? "#166534"
                        : videoCompleted
                        ? "#3f6212"
                        : "#1d4ed8",
                      fontSize: "12px",
                      fontWeight: 700,
                    }}
                  >
                    {completed
                      ? "Tamamlandı"
                      : videoCompleted
                      ? "Eğitim Tamamlandı"
                      : "Devam Ediyor"}
                  </span>

                  <span
                    style={{
                      padding: "6px 10px",
                      borderRadius: "999px",
                      background: item.pre_exam_completed
                        ? "#eff6ff"
                        : "#fef2f2",
                      border: item.pre_exam_completed
                        ? "1px solid #bfdbfe"
                        : "1px solid #fecaca",
                      color: item.pre_exam_completed ? "#1d4ed8" : "#991b1b",
                      fontSize: "12px",
                      fontWeight: 700,
                    }}
                  >
                    {item.pre_exam_completed
                      ? "Ön Sınav Tamam"
                      : "Ön Sınav Bekliyor"}
                  </span>

                  <span
                    style={{
                      padding: "6px 10px",
                      borderRadius: "999px",
                      background: "#fff7ed",
                      border: "1px solid #fdba74",
                      color: "#9a3412",
                      fontSize: "12px",
                      fontWeight: 700,
                    }}
                  >
                    Final Hak: {finalAttemptsLeft}
                  </span>

                  {showFinalScore && finalScore !== null ? (
                    <span
                      style={{
                        padding: "6px 10px",
                        borderRadius: "999px",
                        background: finalScore >= 60 ? "#dcfce7" : "#fee2e2",
                        border:
                          finalScore >= 60
                            ? "1px solid #86efac"
                            : "1px solid #fca5a5",
                        color: finalScore >= 60 ? "#166534" : "#b91c1c",
                        fontSize: "12px",
                        fontWeight: 700,
                      }}
                    >
                      Final: {finalScore}
                    </span>
                  ) : null}

                  {completed ? (
                    <>
                      <button
                        onClick={() =>
                          window.open(
                            `/api/training/certificate/${item.id}`,
                            "_blank",
                            "noopener,noreferrer"
                          )
                        }
                        style={{
                          padding: "6px 10px",
                          borderRadius: "999px",
                          background: "#ede9fe",
                          border: "1px solid #c4b5fd",
                          color: "#5b21b6",
                          fontSize: "12px",
                          fontWeight: 700,
                          cursor: "pointer",
                        }}
                      >
                        Sertifika
                      </button>

                      <button
                        onClick={() =>
                          window.open(
                            `/api/training/attendance-certificate/${item.id}`,
                            "_blank",
                            "noopener,noreferrer"
                          )
                        }
                        style={{
                          padding: "6px 10px",
                          borderRadius: "999px",
                          background: "#ecfeff",
                          border: "1px solid #99f6e4",
                          color: "#0f766e",
                          fontSize: "12px",
                          fontWeight: 700,
                          cursor: "pointer",
                        }}
                      >
                        Katılım Belgesi
                      </button>
                    </>
                  ) : null}
                </div>

                <button
                  onClick={() => router.push(`/portal/training/${item.id}`)}
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    background: completed ? "#16a34a" : "#2563eb",
                    color: "#fff",
                    border: "none",
                    borderRadius: "10px",
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Eğitime Git
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
}